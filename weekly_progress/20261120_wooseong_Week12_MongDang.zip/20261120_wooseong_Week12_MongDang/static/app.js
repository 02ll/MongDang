const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const files = { problem: null, solution: null };
let single = false;

/* ---------- 공통 ---------- */
function esc(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3200);
}
function typeset(el) { if (window.MathJax && MathJax.typesetPromise) MathJax.typesetPromise([el]); }
function verdictClass(v) { return v === '정답' ? 'ok' : v === '오답' ? 'bad' : 'unk'; }
// 정답/오답 배지 (내 흔적 목록, 실수 노트에서 같이 씀)
function verdictBadge(v) { return `<span class="vd ${verdictClass(v)}">${esc(v)}</span>`; }
// 틀린 곳 설명 세 줄 (결과 화면의 '틀린 곳', 실수 노트에서 같이 씀)
function fixDetail(e) {
  return `<dl><dt>내가 쓴 것</dt><dd>${esc(e.wrote)}</dd>
    <dt>왜 틀렸나</dt><dd>${esc(e.why_wrong)}</dd>
    <dt>이렇게 고치기</dt><dd>${esc(e.correct)}</dd></dl>`;
}
const fmtDate = ms => new Date(ms).toLocaleDateString('ko-KR');
const fmtTime = ms => new Date(ms).toLocaleString('ko-KR');

// 서버에 요청하고 JSON으로 받는다. 실패하면 서버가 보낸 오류 문장으로 예외를 던진다
async function getJSON(url, init) {
  let r;
  try { r = await fetch(url, init); }
  catch { throw new Error('몽당 서버에 연결할 수 없어요. 터미널에서 python mongdang.py 가 켜져 있는지 확인해 주세요.'); }
  let j;
  try { j = await r.json(); } catch { throw new Error('서버 응답을 읽지 못했어요'); }
  if (!r.ok || j.error) throw new Error(j.error || '요청에 실패했어요');
  return j;
}

// AI 작업을 맡기고, 끝날 때까지 2초마다 /status 로 확인한다
async function runJob(url, init, onTick) {
  const { job_id } = await getJSON(url, init);
  const t0 = Date.now();
  while (true) {
    await new Promise(r => setTimeout(r, 2000));
    if (Date.now() - t0 > 260000) throw new Error('시간이 너무 오래 걸려요. 다시 시도해 주세요.');
    const j = await getJSON('/status/' + job_id);
    if (j.status === 'done') return j.data;
    if (onTick) onTick(Math.round((Date.now() - t0) / 1000));
  }
}

/* ---------- 탭 ---------- */
$$('.tab').forEach(b => b.onclick = () => {
  // 지난 기록을 보다가 '분석하기' 탭을 누르면 업로드 화면으로 돌아간다
  if (b.dataset.tab === 'home' && $('#result').dataset.past) {
    $('#result').classList.add('hidden');
    $('#upload').classList.remove('hidden');
  }
  showTab(b.dataset.tab);
});
function showTab(name, render = true) {
  $$('.tab').forEach(b => b.classList.toggle('on', b.dataset.tab === name));
  $('#home').classList.toggle('hidden', name !== 'home');
  $('#trace').classList.toggle('hidden', name !== 'trace');
  if (name === 'trace' && render) renderTrace();
  window.scrollTo({ top: 0 });
}

/* ---------- 업로드 ---------- */
function renderEmpty(kind) {
  if (files[kind]) return;
  const isP = kind === 'problem';
  const badge = isP ? (single ? '사진 한 장' : 'STEP 1') : 'STEP 2';
  const big = isP ? (single ? '문제 + 풀이 사진' : '문제 사진') : '내 풀이 사진';
  const small = isP && single ? '문제지에 바로 푼 사진 한 장이면 돼요' : '끌어다 놓거나 클릭해서 선택';
  const dz = $('#dz-' + kind);
  dz.querySelector('.empty-state')?.remove();
  dz.insertAdjacentHTML('beforeend', `<div class="empty-state"><span class="badge">${badge}</span>
    <div class="plus">+</div><div class="big">${big}</div><div class="small">${small}</div></div>`);
}
function updateGo() { $('#go').disabled = !(files.problem && (single || files.solution)); }

function setFile(kind, file) {
  if (!file || !file.type.startsWith('image/')) { toast('이미지 파일만 올릴 수 있어요'); return; }
  files[kind] = file;
  const dz = $('#dz-' + kind);
  dz.classList.add('filled');
  dz.querySelectorAll('.empty-state, img, .fbar').forEach(el => el.remove());
  dz.insertAdjacentHTML('beforeend', `<img src="${URL.createObjectURL(file)}" alt="">
    <div class="fbar"><span>${esc(file.name)}</span><button type="button">다시 고르기</button></div>`);
  dz.querySelector('.fbar button').onclick = e => { e.preventDefault(); e.stopPropagation(); dz.querySelector('input').click(); };
  updateGo();
}

['problem', 'solution'].forEach(kind => {
  const dz = $('#dz-' + kind), input = dz.querySelector('input');
  renderEmpty(kind);
  input.onchange = () => { if (input.files[0]) setFile(kind, input.files[0]); input.value = ''; };
  ['dragenter', 'dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('over'); }));
  dz.addEventListener('drop', e => { if (e.dataTransfer.files[0]) setFile(kind, e.dataTransfer.files[0]); });
});
// 창 아무 데나 떨어뜨렸을 때 브라우저가 파일을 열어버리는 것 방지
['dragover', 'drop'].forEach(ev => window.addEventListener(ev, e => e.preventDefault()));

// 한 장 모드
$('#single').onchange = e => {
  single = e.target.checked;
  $('#dz-solution').classList.toggle('hidden', single);
  $('.drops').classList.toggle('one', single);
  renderEmpty('problem');
  updateGo();
};

// Ctrl+V 붙여넣기: 비어 있는 칸부터 채움
window.addEventListener('paste', e => {
  if ($('#upload').classList.contains('hidden')) return;
  const item = [...(e.clipboardData?.items || [])].find(i => i.type.startsWith('image/'));
  if (!item) return;
  const f = item.getAsFile();
  const kind = single || !files.problem ? 'problem' : 'solution';
  setFile(kind, new File([f], 'pasted-' + kind + '.png', { type: f.type }));
  toast(single ? '사진을 붙여넣었어요' : (kind === 'problem' ? '문제' : '풀이') + ' 사진으로 붙여넣었어요');
});

function resetUpload() {
  files.problem = files.solution = null;
  ['problem', 'solution'].forEach(kind => {
    const dz = $('#dz-' + kind);
    dz.classList.remove('filled');
    dz.querySelectorAll('img, .fbar').forEach(el => el.remove());
    renderEmpty(kind);
  });
  updateGo();
  $('#result').classList.add('hidden');
  $('#upload').classList.remove('hidden');
}

/* ---------- 분석 ---------- */
$('#go').onclick = () => startAnalysis();

// corrections: 판독 정정 목록, replaceId: 다시 분석할 때 바꿀 원래 기록 번호
async function startAnalysis(corrections, replaceId) {
  const fromResult = !$('#result').classList.contains('hidden');
  $('#upload').classList.add('hidden');
  $('#result').classList.add('hidden');
  $('#loading').classList.remove('hidden');
  window.scrollTo({ top: 0 });
  const texts = ['풀이를 읽는 중...', '오류를 찾는 중...', '진단을 정리하는 중...'];
  const dots = $$('.dots i');
  let i = 0;
  dots.forEach((d, k) => d.classList.toggle('on', k === 0));
  $('#lt').textContent = corrections ? '고친 내용으로 다시 보는 중...' : texts[0];
  $('#lp').textContent = '잠시만 기다려 주세요 (보통 10~40초)';
  const timer = setInterval(() => {
    i = Math.min(i + 1, 2);
    $('#lt').textContent = texts[i];
    dots.forEach((d, k) => d.classList.toggle('on', k <= i));
  }, 7000);

  try {
    const fd = new FormData();
    fd.append('problem', files.problem);
    if (single) fd.append('single', '1'); else fd.append('solution', files.solution);
    if (corrections) fd.append('corrections', JSON.stringify(corrections));
    if (replaceId) fd.append('replace', replaceId);
    // 저장은 서버가 분석이 끝나자마자 한다
    const data = await runJob('/analyze', { method: 'POST', body: fd },
      s => { $('#lp').textContent = '잠시만 기다려 주세요 (' + s + '초 경과)'; });
    renderResult(data, {
      problem: URL.createObjectURL(files.problem),
      solution: single ? null : URL.createObjectURL(files.solution),
    });
  } catch (err) {
    toast(err.message);
    $(corrections && fromResult ? '#result' : '#upload').classList.remove('hidden');
  } finally {
    clearInterval(timer);
    $('#loading').classList.add('hidden');
  }
}

/* ---------- 결과 화면 ---------- */
// back: 지난 기록을 열 때 돌아갈 곳 { label, go }. 방금 분석한 결과면 없음
function renderResult(d, thumbs, back) {
  // 원본 사진이 있을 때만 판독 수정 후 다시 분석할 수 있다 (지난 기록은 원본이 없음)
  const canFix = !back && !!files.problem && (single || !!files.solution);
  const concepts = d.concepts || [], errors = d.errors || [], abandoned = d.abandoned || [];
  const counts = d.mistake_counts || {};  // 서버가 센 횟수 (이번 분석 포함)

  const stepsHTML = (d.steps || []).map((s, n) => `
    <div class="step" data-n="${n}">
      <div class="dot ${esc(s.status)}">${s.status === 'ok' ? '✓' : s.status === 'error' ? '!' : '?'}</div>
      <div class="sb"><div class="t">${esc(s.title)}</div>
        <div class="w">${esc(s.student_wrote)}</div>
        ${canFix ? '<textarea class="fix hidden" rows="2"></textarea>' : ''}
        <div>${esc(s.comment)}</div>
        ${canFix ? '<button type="button" class="fixbtn">잘못 읽었어요</button>' : ''}
      </div>
    </div>`).join('');

  const mistakeBox = (e, i) => {
    const m = String(e.mistake || '').trim();
    if (!m) return '';
    const n = counts[m] || 1;
    return `<div class="rule">
      <div class="rl">자주 하는 실수
        <span class="tag ${n > 1 ? 'rep' : ''}">${n > 1 ? `기록에서 ${n}번째` : '처음 발견'}</span>
        ${d.history_id ? `<button type="button" class="notebtn" data-i="${i}">실수 노트 →</button>` : ''}</div>
      <div class="rt">${esc(m)}</div></div>`;
  };
  const errorsHTML = errors.length ? errors.map((e, i) => `
    <div class="err">
      <span class="k ${e.kind === '계산 실수' ? 'calc' : ''}">${esc(e.kind)}</span><b>${esc(e.step)}</b>
      ${mistakeBox(e, i)}
      ${fixDetail(e)}
    </div>`).join('') : '<div class="good">틀린 곳이 없어요. 풀이가 정확해요.</div>';

  const dirClass = v => v === '맞는 방향' ? 'right' : v === '틀린 방향' ? 'wrong' : '';
  const abandonedHTML = abandoned.length ? `
    <details class="sec" open><summary>지우고 버린 흔적</summary><div class="body">
      ${abandoned.some(a => a.direction === '맞는 방향') ? '<div class="gem">버린 시도 중에 사실 맞는 방향이 있었어요. 초록색 흔적을 확인해 보세요.</div>' : ''}
      ${abandoned.map(a => `
        <div class="ab ${dirClass(a.direction)}">
          <span class="k">${esc(a.direction || '판단 불가')}</span><b>${esc(a.where)}</b>
          <dl><dt>남아 있던 흔적</dt><dd>${esc(a.what)}</dd>
            <dt>몽당의 생각</dt><dd>${esc(a.comment)}</dd></dl>
        </div>`).join('')}
    </div></details>` : '';

  $('#result').innerHTML = `
    <button class="back" id="back">${back ? back.label : '← 새 문제 분석하기'}</button>
    <div class="summary ${verdictClass(d.verdict)}">
      <span class="v">${esc(d.verdict)}</span>
      <div class="line">${esc(d.one_line)}</div>
      ${concepts.length ? `<div class="cc">${concepts.map((c, i) => `<span>${i === 0 ? '핵심 개념 · ' : ''}${esc(c)}</span>`).join('')}</div>` : ''}
      <div class="thumbs"><img src="${thumbs.problem}" alt="문제">${thumbs.solution ? `<img src="${thumbs.solution}" alt="풀이">` : ''}</div>
    </div>
    <details class="sec" open><summary>내 풀이</summary><div class="body">
      ${d.problem ? `<details class="prob"><summary>AI가 읽은 문제 보기</summary><div>${esc(d.problem)}</div></details>` : ''}
      ${canFix ? `<div class="fixhint">AI가 손글씨를 잘못 읽었다면 그 단계의 '잘못 읽었어요'를 눌러 고쳐 주세요.</div>` : ''}
      ${stepsHTML}
      ${canFix ? `<div class="refix hidden">고친 내용을 실제 풀이로 보고 다시 분석해요<button type="button" class="go small" id="refixBtn">다시 분석하기</button></div>` : ''}
    </div></details>
    <details class="sec" open><summary>틀린 곳</summary><div class="body">${errorsHTML}</div></details>
    ${abandonedHTML}
    <div class="pwrap"><button type="button" class="go small" id="practiceBtn">연습 문제 만들기</button><div class="pbody"></div></div>`;

  $('#result').dataset.past = back ? '1' : '';
  $('#result').classList.remove('hidden');
  $('#upload').classList.add('hidden');
  if (back) showTab('home');
  $('#back').onclick = () => back ? back.go() : resetUpload();
  if (canFix) wireFix(d);
  $('#practiceBtn').onclick = () => makePractice($('#practiceBtn'), $('#result .pbody'), {
    problem: d.problem, concepts, mistakes: errors.map(e => e.mistake),
  });
  $$('#result .notebtn').forEach(b => b.onclick = () => openNote(errors[+b.dataset.i].mistake.trim()));
  typeset($('#result'));
  window.scrollTo({ top: 0 });
}

/* ---------- 판독 수정 ---------- */
function wireFix(d) {
  const openFixes = () => [...$$('#result .fix')].filter(t => !t.classList.contains('hidden'));
  $$('#result .step').forEach(stepEl => {
    const s = d.steps[+stepEl.dataset.n];
    const ta = stepEl.querySelector('.fix'), btn = stepEl.querySelector('.fixbtn');
    btn.onclick = () => {
      const open = ta.classList.contains('hidden');  // 지금 닫혀 있으면 연다
      ta.classList.toggle('hidden', !open);
      btn.classList.toggle('on', open);
      btn.textContent = open ? '수정 취소' : '잘못 읽었어요';
      if (open) { if (!ta.value) ta.value = s.student_wrote || ''; ta.focus(); }
      $('#result .refix').classList.toggle('hidden', !openFixes().length);
    };
  });
  $('#refixBtn').onclick = () => {
    const corr = [];
    $$('#result .step').forEach(stepEl => {
      const ta = stepEl.querySelector('.fix'), s = d.steps[+stepEl.dataset.n];
      const v = ta.value.trim();
      if (!ta.classList.contains('hidden') && v && v !== String(s.student_wrote || '').trim())
        corr.push({ title: s.title, read: s.student_wrote, wrote: v });
    });
    if (!corr.length) { toast('고친 내용이 없어요'); return; }
    startAnalysis(corr, d.history_id);
  };
}

/* ---------- 연습 문제 (결과 화면, 실수 노트 공통) ---------- */
async function makePractice(btn, box, payload) {
  const label = btn.textContent;
  btn.disabled = true;
  btn.innerHTML = '<span class="mini"></span>문제 만드는 중...';
  try {
    const data = await runJob('/practice', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload),
    });
    const ps = data.problems || [];
    if (!ps.length) throw new Error('문제를 만들지 못했어요. 다시 눌러 주세요.');
    if (!btn.isConnected) return;  // 기다리는 동안 다른 화면으로 넘어감
    btn.remove();
    box.innerHTML = ps.map((p, i) => `
      <div class="sim">
        <b class="sn">연습 ${i + 1}</b>
        <div class="q">${esc(p.question)}</div>
        ${p.hint ? `<details><summary>힌트 보기</summary><div>${esc(p.hint)}</div></details>` : ''}
        <details><summary>정답 보기</summary>
          <div><b>정답</b> ${esc(p.answer)}</div>
          ${p.trap ? `<div class="trap"><b>함정</b> ${esc(p.trap)}</div>` : ''}
          <div class="sol">${esc(p.solution)}</div></details>
      </div>`).join('');
    typeset(box);
  } catch (err) {
    if (!btn.isConnected) return;
    toast(err.message);
    btn.disabled = false;
    btn.textContent = label;
  }
}

/* ---------- 내 흔적 ---------- */
async function renderTrace() {
  const el = $('#trace');
  const hero = sub => `<div class="hero"><h1>내 <em>흔적</em></h1><p>${sub}</p></div>`;
  let h;
  try { h = await getJSON('/history'); }
  catch (err) { el.innerHTML = hero('') + `<div class="empty">기록을 불러오지 못했어요.<br>${esc(err.message)}</div>`; return; }
  if (!h.total) {
    el.innerHTML = hero('분석할 때마다 여기에 쌓여요') + '<div class="empty">아직 기록이 없어요.<br>문제를 하나 분석해 보세요!</div>';
    return;
  }
  const max = h.concepts.length ? h.concepts[0].count : 1;

  el.innerHTML = hero('쌓인 풀이로 내 약점을 한눈에') + `
    <div class="stats">
      <div class="stat"><div class="n">${h.total}</div><div class="l">분석한 문제</div></div>
      <div class="stat"><div class="n">${h.right}</div><div class="l">정답</div></div>
      <div class="stat"><div class="n">${h.wrong}</div><div class="l">오답</div></div>
    </div>
    <div class="h2">자주 하는 실수${h.mistakes.length ? '<small>누르면 실수 노트가 열려요</small>' : ''}</div>
    <div class="box">${h.mistakes.length ? h.mistakes.map((r, i) => `
      <div class="rr ${r.count > 1 ? 'hot' : ''}" data-i="${i}"><div class="rc">${r.count}회</div>
        <div class="rx">${esc(r.mistake)}<div class="rd">마지막 ${fmtDate(r.last)}</div></div><div class="arr">›</div></div>`).join('')
      : '<div class="muted">아직 찾은 실수가 없어요. 오답을 분석하면 여기에 쌓여요</div>'}</div>
    <div class="h2">자주 걸리는 핵심 개념</div>
    <div class="box">${h.concepts.length ? h.concepts.map(c => `
      <div class="rk"><div class="nm">${esc(c.name)}</div><div class="bar"><i style="width:${c.count / max * 100}%"></i></div><div class="ct">${c.count}회</div></div>`).join('')
      : '<div class="muted">아직 집계할 개념이 없어요</div>'}</div>
    <div class="h2">지난 분석</div>
    <div class="hist">${h.items.map(x => `
      <div class="hc" data-id="${x.id}">
        <button class="x" data-del="${x.id}" title="삭제">×</button>
        <img src="/thumb/${x.id}/problem" alt="">
        ${verdictBadge(x.verdict)}
        <div class="ln">${esc(x.one_line)}</div>
        <div class="dt">${fmtTime(x.created_at)}</div>
      </div>`).join('')}</div>`;

  el.querySelectorAll('.rr').forEach(r => r.onclick = () => openNote(h.mistakes[+r.dataset.i].mistake));
  el.querySelectorAll('.hc').forEach(c => c.onclick = () =>
    openRecord(c.dataset.id, { label: '← 내 흔적으로', go: () => showTab('trace') }));
  el.querySelectorAll('.x').forEach(b => b.onclick = async e => {
    e.stopPropagation();  // 카드가 열리지 않게
    try { await getJSON('/history/' + b.dataset.del, { method: 'DELETE' }); } catch (err) { toast(err.message); }
    renderTrace();
  });
  typeset(el);
}

// 지난 기록 하나를 서버에서 받아 결과 화면으로 보여 준다
async function openRecord(id, back) {
  try {
    const r = await getJSON('/history/' + id);
    renderResult(r.data, r.thumbs, back);
  } catch (err) { toast(err.message); }
}

/* ---------- 실수 노트: 실수 하나가 나온 문제를 모아 보기 ---------- */
async function openNote(text) {
  let n;
  try { n = await getJSON('/mistake-note?text=' + encodeURIComponent(text)); }
  catch (err) { toast(err.message); return; }
  const items = n.items, latest = items[0], first = items[items.length - 1];
  showTab('trace', false);
  const el = $('#trace');
  el.innerHTML = `
    <button class="back" id="noteBack">← 내 흔적으로</button>
    <div class="notehead">
      <div class="rl">실수 노트</div>
      <div class="rt">${esc(n.text)}</div>
      <div class="meta">${items.length}번 나옴 · 처음 ${fmtDate(first.created_at)} · 마지막 ${fmtDate(latest.created_at)}</div>
    </div>
    <div class="pwrap"><button type="button" class="go small" id="notePractice">이 실수로 연습 문제 만들기</button><div class="pbody"></div></div>
    <div class="h2">이 실수가 나온 문제</div>
    ${items.map(x => `
      <div class="occ">
        <img src="/thumb/${x.id}/problem" alt="">
        <div class="ob">
          <div class="oh">${verdictBadge(x.verdict)} ${fmtTime(x.created_at)}</div>
          <div class="os">${esc(x.step)}</div>
          ${fixDetail(x)}
          <button type="button" class="open" data-id="${x.id}">이 풀이 전체 보기</button>
        </div>
      </div>`).join('')}`;

  $('#noteBack').onclick = () => showTab('trace');
  // 가장 최근에 이 실수가 나온 문제를 바탕으로, 이 실수만 노리는 문제를 만든다
  $('#notePractice').onclick = () => makePractice($('#notePractice'), $('#trace .pbody'),
    { problem: latest.problem, mistakes: [n.text] });
  el.querySelectorAll('.open').forEach(b => b.onclick = () =>
    openRecord(b.dataset.id, { label: '← 실수 노트로', go: () => openNote(n.text) }));
  typeset(el);
}
