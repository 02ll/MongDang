"""
몽당 - 손글씨 수학 풀이를 읽고 어디서 막혔는지 짚어 주는 웹앱 (Flask + Gemini)

폴더 구성
  mongdang.py              서버 (이 파일, 파이썬만)
  templates/index.html     화면 뼈대 (HTML)
  static/style.css         화면 꾸밈 (CSS)
  static/app.js            화면 동작 (JavaScript): 업로드, 결과, 내 흔적, 실수 노트
  measure_consistency.py   진단 일관성 측정 (9주차)
  mongdang.db              기록 파일 (처음 실행할 때 자동으로 생김)

이 파일의 순서
  1. 설정          모델, API 키, 기록 파일 위치
  2. AI 호출       서버가 붐비면 모델을 바꿔 가며 다시 시도
  3. 프롬프트      풀이 분석, 연습 문제
  4. AI 응답 정리  개념 정렬, JSON 읽기
  5. 요청 값 정리  사진, 판독 정정
  6. 작업          분석은 오래 걸려서 백그라운드로 돌리고, 브라우저는 /status 로 결과를 확인
  7. 기록 저장     SQLite (analyses, mistakes 표)
  8. 주소          /analyze, /practice, /status, /history, /mistake-note

실행: GEMINI_API_KEY 를 설정한 터미널에서 이 폴더로 이동한 뒤  python mongdang.py  →  http://127.0.0.1:5000
"""
import os
import io
import json
import random
import re
import sqlite3
import time
import threading
import uuid
from contextlib import closing, contextmanager
from flask import Flask, request, jsonify, Response, render_template
from google import genai
from google.genai import types
from PIL import Image, ImageOps

# =========================
# 설정
# =========================
MODEL_NAME = os.environ.get("MONGDANG_MODEL", "gemini-3.6-flash")

api_key = os.environ.get("GEMINI_API_KEY")
if not api_key:
    raise SystemExit("GEMINI_API_KEY 환경변수가 설정되지 않았습니다.")

client = genai.Client(api_key=api_key, http_options=types.HttpOptions(timeout=90000))
app = Flask(__name__)

# 주 모델이 붐비면 순서대로 넘어갈 예비 모델들
FALLBACK_MODELS = [m.strip() for m in os.environ.get(
    "MONGDANG_FALLBACKS", "gemini-3.8-flash").split(",") if m.strip()]
MODEL_CHAIN = [MODEL_NAME] + [m for m in FALLBACK_MODELS if m != MODEL_NAME]
BUSY_WORDS = ("503", "UNAVAILABLE", "429", "RESOURCE_EXHAUSTED", "overloaded", "high demand", "500", "INTERNAL", "DEADLINE", "timed out", "Timeout", "timeout", "ReadTimeout", "ConnectError", "disconnected")

# 작업 하나에 쓸 수 있는 전체 시간 (프론트 대기 한도 260초보다 짧게)
JOB_TIME_BUDGET = 220

# AI가 답하기 전에 "생각"할 수 있는 분량.
# 1024로 제한했을 때 어려운 문제에서 AI가 문제를 끝까지 풀지 못하고 진단이 매번 달라졌다 (측정 결과 9회 중 약 3회만 정확).
THINKING_BUDGET = int(os.environ.get("MONGDANG_THINKING", "4096"))
SEED = 7  # 같은 입력에는 최대한 같은 답이 나오도록 고정

# 분석 기록을 저장할 SQLite 파일 (앱 파일과 같은 폴더). 브라우저 캐시를 지워도 기록이 남는다.
DB_PATH = os.environ.get("MONGDANG_DB") or os.path.join(os.path.dirname(os.path.abspath(__file__)), "mongdang.db")


# =========================
# AI 호출
# =========================
def make_config(with_thinking=True, max_tokens=12000):
    kw = dict(response_mime_type="application/json", temperature=0, max_output_tokens=max_tokens)
    if with_thinking:
        try:
            kw["thinking_config"] = types.ThinkingConfig(thinking_budget=THINKING_BUDGET)
        except Exception:
            pass
    try:
        return types.GenerateContentConfig(seed=SEED, **kw)
    except Exception:
        # seed를 지원하지 않는 라이브러리 버전이면 seed 없이
        return types.GenerateContentConfig(**kw)


_discovered = None


def model_chain():
    """설정한 모델(주 모델 + 예비 모델) 뒤에, 이 API 키로 실제 쓸 수 있는 다른 Flash 모델을 붙인다.
    모델 이름을 짐작해서 적는 대신, 서버에 목록을 물어봐서 확인된 것만 쓴다. (처음 한 번만 조회)"""
    global _discovered
    if _discovered is None:
        _discovered = []
        try:
            for m in client.models.list():
                name = (m.name or "").split("/")[-1]
                actions = getattr(m, "supported_actions", None) or []
                if ("flash" in name and "generateContent" in actions
                        and not any(w in name for w in ("lite", "image", "tts", "live", "audio", "embedding"))):
                    _discovered.append(name)
            _discovered.sort(reverse=True)  # 버전 숫자가 높은 것부터
            print(f"[몽당] 사용 가능한 Flash 모델: {_discovered}", flush=True)
        except Exception as e:
            print(f"[몽당] 모델 목록 조회 실패 (설정한 모델만 사용): {str(e)[:120]}", flush=True)
    return MODEL_CHAIN + [m for m in _discovered if m not in MODEL_CHAIN]


def generate_with_retry(contents, max_tokens=12000, deadline=None):
    """모델 호출. 서버가 붐비면(503 등) 모델을 번갈아 바꿔 가며, 한 바퀴 돌 때마다 점점 길게 쉬었다가 다시 시도한다.
    - 한 모델이 붐비는 동안 같은 모델만 계속 두드리지 않고 다른 모델로 바로 넘어간다.
    - 대기 시간은 2초, 4초, 8초, 16초... 로 늘리고(최대 20초), 여러 요청이 동시에 몰리지 않게 약간의 무작위 시간을 더한다.
    - deadline(시각)이 지나면 멈춘다."""
    if deadline is None:
        deadline = time.time() + 170
    chain = model_chain()
    no_thinking = set()   # 생각 설정을 거부한 모델
    dead = set()          # 이 키로는 없는 모델 (NOT_FOUND)
    last_err = None
    rnd = 0
    while time.time() < deadline:
        alive = [m for m in chain if m not in dead]
        if not alive:
            break
        for model in alive:
            if time.time() >= deadline:
                break
            with_thinking = model not in no_thinking
            try:
                print(f"[몽당] {model} 시도 (라운드 {rnd+1}, thinking={with_thinking}, max={max_tokens})", flush=True)
                t0 = time.time()
                r = client.models.generate_content(
                    model=model, contents=contents,
                    config=make_config(with_thinking=with_thinking, max_tokens=max_tokens),
                )
                print(f"[몽당] {model} 성공 {time.time()-t0:.1f}초", flush=True)
                return r
            except Exception as e:
                last_err = e
                msg = str(e)
                print(f"[몽당] {model} 실패: {msg[:200]}", flush=True)
                if with_thinking and ("thinking" in msg.lower() or "INVALID_ARGUMENT" in msg):
                    no_thinking.add(model)   # 다음 라운드에선 생각 설정 없이
                    continue
                if "NOT_FOUND" in msg or "404" in msg:
                    dead.add(model)
                    continue
                if not any(w in msg for w in BUSY_WORDS):
                    raise
        # 모든 모델이 한 바퀴 다 실패 → 점점 길게 쉬고 다시
        wait = min(20, 2 * 2 ** rnd) + random.uniform(0, 1)
        if time.time() + wait >= deadline:
            break
        print(f"[몽당] 모든 모델이 붐빔. {wait:.1f}초 쉬고 다시 시도", flush=True)
        time.sleep(wait)
        rnd += 1
    raise last_err or TimeoutError("분석 시간이 너무 오래 걸렸어요")


# =========================
# 프롬프트
# =========================
IMAGES_TWO = "두 장의 이미지가 주어진다. 첫 번째 = 수학 문제, 두 번째 = 학생이 직접 쓴 풀이."
IMAGES_ONE = ("한 장의 이미지가 주어진다. 이 이미지 안에 수학 문제와 학생이 직접 쓴 풀이가 함께 있다. "
              "인쇄된 글씨(문제 영역)는 문제로, 그 위나 옆에 쓴 손글씨는 학생의 풀이로 구분해서 읽는다. "
              "문제에 원래 있던 표시와 학생이 쓴 흔적이 헷갈리면 확정하지 말고 \"판독이 불확실함\"이라고 쓴다.")

PROMPT = """
너는 수학 학습 분석 AI인 몽당이다.
__IMAGES__
정답과 해설을 주는 것이 목적이 아니다. 학생의 실제 풀이 흔적을 보고 어디서 왜 막혔는지 진단한다.

원칙:
- 학생의 풀이를 실제로 분석한 결과만 말한다. 정확하면 정확하다고 인정한다.
- 손글씨가 불분명하면 확정하지 말고 "판독이 불확실함"이라고 쓴다.
- 오류가 명확하지 않으면 추측해서 단정하지 않는다.
- 학생에게 보여 줄 문장은 짧고 쉽게 쓴다. 같은 내용을 여러 칸에 되풀이하지 않는다.
- steps 의 student_wrote 에는 학생이 쓴 내용을 해석하지 말고 읽은 그대로 옮긴다. (학생이 판독 결과를 확인하고 고칠 수 있도록)
- steps 의 comment 는 한 줄로 쓴다. 틀린 단계는 무엇이 틀렸는지만 짧게 쓰고, 왜 틀렸는지와 고치는 법은 errors 에만 쓴다.

[진단 순서] 반드시 이 순서로 판단하고, JSON도 이 순서대로 채운다.
1. reference: 학생 풀이를 평가하기 전에 먼저 문제를 직접 끝까지 푼다.
   - 그림이나 그래프의 모양만 보고 함수 사이의 관계(역함수, 대칭, 평행이동, 접함 등)를 짐작하지 않는다. 반드시 식을 직접 변형하거나 대입해서 확인하고, 그 확인 과정을 key_checks 에 쓴다.
   - 정답까지 구한 뒤, 검산한다.
2. steps, errors: 학생 풀이의 각 단계를 reference 와 하나씩 비교해 판단한다. reference 와 다르게 판단할 근거가 없으면 학생의 단계를 맞다고 하지 않는다.
3. 나머지 칸(verdict, one_line, concepts)은 errors 에서 내린 판단을 요약만 한다. 새로운 판단을 하지 않는다.
   - 한 칸에서 틀렸다고 한 내용을 다른 칸에서 맞았다고 하지 않는다. (예: errors 에서 어떤 관계를 잘못 판단했다고 했다면, one_line 에서 그 관계를 "잘 활용했다"고 하지 않는다.)
4. kind 구분: 그 단계의 근거가 된 수학적 사실이나 관계를 잘못 알았으면 "개념 오류", 방법과 근거는 맞는데 계산만 틀렸으면 "계산 실수".

[자주 하는 실수]
- 오류마다 학생이 "자주 하는 실수"를 찾아 errors.mistake 에 쓴다.
  자주 하는 실수 = 학생이 맞다고 믿고 일관되게 적용하는 잘못된 방식. 개념 이름이 아니라, 학생이 실제로 하는 행동을 "~한다" 형태의 한 문장으로 쓴다.
  예: "$(a+b)^2$ 를 $a^2+b^2$ 로 전개한다", "부등식 양변에 음수를 곱해도 부등호 방향을 그대로 둔다", "$a^m a^n$ 을 $a^{mn}$ 으로 계산한다"
- 다른 문제에도 그대로 적용될 수 있도록 이 문제의 숫자가 아니라 일반적인 형태로 쓴다.
- 숫자를 잘못 옮겨 적거나 덧셈을 한 번 틀린 것처럼 반복될 만한 실수가 아니라 우연한 실수면 mistake 는 빈 문자열로 둔다. 억지로 만들지 않는다.
__KNOWN_RULES__
[지우고 버린 흔적]
- 지우개 자국, 줄 그어 지운 부분, 쓰다 만 식, 여백의 계산처럼 최종 풀이에 쓰이지 않은 흔적을 찾아 abandoned 에 쓴다.
- 이미지에 실제로 보이는 것만 쓴다. 없으면 빈 배열로 둔다. 흐려서 내용을 읽을 수 없으면 what 에 "판독이 불확실함"이라고 쓴다.
- 각 흔적의 방향이 맞았는지(direction) 판단한다. comment 에는 어떤 접근이었는지 쓰고, 버린 시도가 사실 맞는 방향이었다면 반드시 그렇게 말하고 왜 버렸을지(추정이면 추정이라고 표시)와 계속했다면 어떻게 됐을지를 쓴다.

[개념]
- 학생의 오류나 풀이 습관과 직접 관련된 개념만 최대 3개 고른다. 문제에 쓰인 개념을 전부 나열하지 않는다.
- 학생이 잘못 알고 있던 수학적 사실이 속한 가장 기초 단원은 반드시 포함한다.
- 이름은 아래 [표준 개념 목록]에서 가장 가까운 것을 그대로 고른다. 목록에 정말 없을 때만 교과서 단원 이름 형태로 짧게 새로 쓴다.

[표준 개념 목록]
다항식의 연산, 인수분해, 나머지정리와 인수정리, 복소수, 이차방정식의 근과 계수의 관계, 판별식, 이차함수와 직선의 위치 관계, 이차함수의 최대최소, 여러 가지 방정식, 부등식, 절댓값 방정식과 부등식, 집합의 연산, 명제와 조건, 함수의 정의와 그래프, 합성함수, 역함수, 유리함수와 무리함수, 평행이동과 대칭이동, 경우의 수, 순열과 조합, 확률의 기본 성질, 조건부확률, 통계, 지수와 로그의 계산, 지수함수, 로그함수, 지수함수와 로그함수의 그래프, 지수방정식과 로그방정식, 삼각함수의 정의, 삼각함수의 그래프, 삼각방정식과 부등식, 사인법칙과 코사인법칙, 등차수열, 등비수열, 수열의 합, 점화식, 수학적 귀납법, 함수의 극한, 함수의 연속, 미분계수와 도함수, 접선의 방정식, 함수의 증감과 극값, 부정적분, 정적분, 정적분과 넓이, 이차곡선, 벡터, 공간도형, 기타 계산 실수
- 모든 수식은 LaTeX. 인라인은 $...$ 만 사용한다. ($$ 는 쓰지 않는다.)
- JSON 문자열 안의 백슬래시는 반드시 두 번 쓴다. 예: "$\\\\frac{1}{2}$"

반드시 아래 JSON 형식으로만 답한다. 다른 글은 쓰지 않는다.
{
  "problem": "문제 내용 정리 (조건, 선택지 포함)",
  "reference": {
    "key_checks": ["문제를 푸는 데 결정적인 관계·조건을 식으로 직접 확인한 결과 (한 항목에 한 가지)"],
    "approach": "올바른 풀이의 핵심 흐름 2~4문장",
    "answer": "정답 (구할 수 없으면 판단 불가)"
  },
  "steps": [
    {"title": "단계 이름", "student_wrote": "학생이 쓴 내용", "status": "ok" | "error" | "unclear", "comment": "한 줄 코멘트 (틀린 단계는 무엇이 틀렸는지만)"}
  ],
  "errors": [
    {"step": "오류 단계", "kind": "계산 실수" | "개념 오류", "wrote": "학생이 쓴 내용", "why_wrong": "무엇이 왜 잘못됐나", "correct": "이렇게 고치면 된다", "mistake": "자주 하는 실수 한 문장 또는 빈 문자열"}
  ],
  "abandoned": [
    {"where": "흔적의 위치 (예: 오른쪽 여백, 셋째 줄 위 줄 그은 부분)", "what": "남아 있는 내용을 읽은 그대로", "direction": "맞는 방향" | "틀린 방향" | "판단 불가", "comment": "어떤 접근이었고, 왜 버렸을지, 계속했다면 어땠을지"}
  ],
  "verdict": "정답" | "오답" | "판단 불가능",
  "one_line": "학생에게 건네는 핵심 피드백 1~2문장 (errors 의 판단과 일치해야 함)",
  "concepts": ["개념 이름"]
}
errors, abandoned, concepts 는 해당 없으면 빈 배열로 둔다.
"""

KNOWN_RULES_NOTE = """- 아래는 이 학생에게서 이전에 발견된 자주 하는 실수다. 이번 오류가 이 중 하나와 같은 실수면 mistake 에 그 문장을 글자 하나 바꾸지 말고 그대로 쓴다. (같은 실수가 몇 번 반복되는지 세기 위해서다.) 다른 실수면 새로 쓴다. 억지로 맞추지 않는다.
"""

CORRECTION_NOTE = """
[학생의 판독 정정]
이전 분석에서 AI가 손글씨를 잘못 읽은 부분을 학생이 직접 고쳤다.
아래 정정 내용을 학생이 실제로 쓴 것으로 간주하고 처음부터 다시 분석한다. 이미지와 달라 보여도 정정 내용을 우선한다.
"""

# 연습 문제: 결과 화면과 실수 노트가 함께 쓴다
PRACTICE_PROMPT = """
너는 수학 학습 도우미 몽당이다. 학생이 아래 문제를 풀었다.

[원래 문제]
__PROBLEM__

[관련 개념]
__CONCEPTS__

[학생이 자주 하는 실수 (학생이 맞다고 믿고 쓰는 잘못된 방식)]
__MISTAKES__

이 학생을 위한 연습 문제 2개를 만든다.
- 자주 하는 실수가 있으면, 그 실수대로 풀면 반드시 틀린 답이 나오고 올바르게 풀어야만 정답이 나오도록 만든다.
  실수대로 해도 우연히 정답이 나오는 문제는 만들지 않는다. trap 에는 그 실수대로 풀면 나오는 오답과 이유를 쓴다.
- 자주 하는 실수가 없으면 trap 은 빈 문자열로 두고, 같은 개념을 다른 각도에서 묻는다. 관련 개념도 없으면(정답을 맞힌 경우) 같은 단원에서 한 단계 어렵게 만든다.
- 원래 문제에서 숫자만 바꾼 문제는 만들지 않는다. 난이도는 원래 문제와 비슷하게 한다.
- 정답은 하나로 확정되어야 한다. 직접 풀어서 정답이 맞는지, 그리고 그 실수대로 풀면 정말 다른 답이 나오는지 반드시 검산한다.
- 모든 수식은 LaTeX. 인라인은 $...$ 만 사용한다.
- JSON 문자열 안의 백슬래시는 반드시 두 번 쓴다. 예: "$\\\\frac{1}{2}$"

반드시 아래 JSON 형식으로만 답한다. 다른 글은 쓰지 않는다.
{
  "problems": [
    {"question": "문제", "hint": "막힐 때 볼 짧은 힌트", "answer": "정답", "trap": "그 실수대로 풀면 나오는 오답과 이유, 또는 빈 문자열", "solution": "핵심만 담은 짧은 풀이"}
  ]
}
"""


def build_prompt(single, corrections, known_rules=None):
    p = PROMPT.replace("__IMAGES__", IMAGES_ONE if single else IMAGES_TWO)
    block = KNOWN_RULES_NOTE + "".join(f"  - {r}\n" for r in known_rules) if known_rules else ""
    p = p.replace("__KNOWN_RULES__\n", block)
    if corrections:
        lines = "\n".join(
            f'- 단계 "{c["title"]}": AI가 "{c["read"]}"(으)로 읽음 → 학생 정정: "{c["wrote"]}"'
            for c in corrections)
        p += CORRECTION_NOTE + lines + "\n위 JSON 형식 규칙은 그대로 지킨다.\n"
    return p


# =========================
# AI 응답 정리
# =========================
# 프롬프트의 [표준 개념 목록]을 코드에서도 그대로 쓴다 (목록 순서 = 교육과정 순서)
STANDARD_CONCEPTS = [c.strip() for c in PROMPT.split("[표준 개념 목록]\n", 1)[1].split("\n", 1)[0].split(",")]
CONCEPT_ORDER = {name: i for i, name in enumerate(STANDARD_CONCEPTS)}


def normalize_analysis(data):
    """개념을 교육과정 순서로 정렬하고, 맨 앞(가장 기초) 개념을 핵심 개념으로 정한다.
    AI가 함께 고르는 개념은 매번 조금씩 달라질 수 있지만, 핵심 개념은 이 규칙으로 정해져서 통계가 흔들리지 않는다."""
    names = []
    for c in data.get("concepts") or []:
        name = str(c.get("name", "") if isinstance(c, dict) else c).strip()  # 10주차 초기 기록은 {"name": ...} 형태
        if name and name not in names:
            names.append(name)
    names.sort(key=lambda n: CONCEPT_ORDER.get(n, len(CONCEPT_ORDER)))  # 목록에 없는 이름은 뒤로
    data["concepts"] = names
    data["primary_concept"] = names[0] if names else ""
    return data


# JSON 문자열 안의 LaTeX 백슬래시 고치기
# - 이미 두 번 쓴 백슬래시(\\)는 그대로 둔다
# - \log, \frac 처럼 뒤에 영문자가 2개 이상 오면 LaTeX 명령이므로 두 번 쓴 것으로 바꾼다
# - 그 밖에 JSON에서 허용되지 않는 \l, \( 같은 것도 두 번 쓴 것으로 바꾼다
_LATEX_BACKSLASH = re.compile(r'\\\\|\\(?=[A-Za-z]{2,})|\\(?![\\"/bfnrtu])')


def repair_backslashes(t):
    return _LATEX_BACKSLASH.sub(lambda m: m.group(0) if m.group(0) == "\\\\" else "\\\\", t)


def parse_json(text):
    t = (text or "").strip()
    if t.startswith("```"):
        t = t.strip("`").strip()
        if t.lower().startswith("json"):
            t = t[4:]
    try:
        data = json.loads(t)
    except json.JSONDecodeError:
        # AI가 LaTeX 백슬래시를 한 번만 쓰면 "Invalid \escape" 오류가 난다.
        # seed가 고정이라 다시 불러도 같은 응답이 오므로, 재시도 대신 여기서 고쳐서 읽는다.
        data = json.loads(repair_backslashes(t))
    if not isinstance(data, dict):
        raise ValueError("JSON 객체가 아님")
    return data


# =========================
# 요청 값 정리
# =========================
def parse_corrections(raw):
    """판독 정정 목록 (브라우저가 JSON 문자열로 보냄)"""
    try:
        items = json.loads(raw or "[]")
    except Exception:
        return []
    if not isinstance(items, list):
        return []
    return [{k: str(c.get(k, ""))[:500] for k in ("title", "read", "wrote")}
            for c in items[:20] if isinstance(c, dict) and str(c.get("wrote", "")).strip()]


def clean_list(raw, limit, max_len):
    """문자열 목록을 빈 값·중복 없이 정리"""
    out = []
    for x in raw if isinstance(raw, list) else []:
        s = str(x or "").strip().replace("\n", " ")[:max_len]
        if s and s not in out:
            out.append(s)
    return out[:limit]


def load_image(file_storage):
    img = Image.open(io.BytesIO(file_storage.read()))
    # 폰 사진은 EXIF 회전 정보로만 세워져 있는 경우가 많아서, 실제 픽셀을 바로 세워 준다
    img = ImageOps.exif_transpose(img)
    img = img.convert("RGB")
    if max(img.size) > 1600:
        img.thumbnail((1600, 1600))
    return img


def make_thumb(img, width=360):
    """기록에 함께 저장할 작은 사진 (JPEG 바이트)"""
    t = img.copy()
    t.thumbnail((width, width * 4))
    buf = io.BytesIO()
    t.save(buf, "JPEG", quality=70)
    return buf.getvalue()


# =========================
# 작업 (분석은 오래 걸려서 백그라운드 스레드로 돌리고, 브라우저는 /status 로 결과를 확인)
# =========================
JOBS = {}


def friendly_error(e):
    msg = str(e)
    if any(w in msg for w in ("503", "UNAVAILABLE", "429", "RESOURCE_EXHAUSTED", "high demand")):
        return "지금 AI 서버가 많이 붐벼요. 잠시 후 다시 눌러 주세요."
    if "timed out" in msg.lower() or "timeout" in msg.lower() or "deadline" in msg.lower():
        return "AI 응답이 너무 늦어요. 잠시 후 다시 시도해 주세요."
    return msg


def run_json_job(job_id, contents, token_steps, post=None):
    """모델을 불러 JSON을 받는다. 응답이 잘려 파싱이 안 되면 출력 한도를 늘려 한 번 더 시도.
    post 가 있으면 결과를 넘기기 전에 한 번 거친다 (분석 결과 정리·저장)."""
    job = JOBS[job_id]
    deadline = time.time() + JOB_TIME_BUDGET
    try:
        for i, max_tokens in enumerate(token_steps):
            if time.time() >= deadline:
                break
            response = generate_with_retry(contents, max_tokens=max_tokens, deadline=deadline)
            text = response.text or ""
            try:
                data = parse_json(text)
            except (json.JSONDecodeError, ValueError):
                print(f"[몽당] JSON 파싱 실패 ({i+1}/{len(token_steps)}). 응답 끝부분:", text[-200:], flush=True)
                continue
            job.update(status="done", data=post(data) if post else data)
            return
        job.update(status="error", error="AI 응답을 읽지 못했어요. 다시 한 번 시도해 주세요.")
    except Exception as e:
        print("[몽당] 작업 실패:", repr(e)[:300], flush=True)
        job.update(status="error", error=friendly_error(e))


def start_job(contents, token_steps, post=None):
    """작업을 시작하고 작업 번호를 바로 돌려준다"""
    now = time.time()
    for k in [k for k, v in JOBS.items() if now - v["t"] > 1800]:  # 30분 지난 작업은 정리
        JOBS.pop(k, None)
    job_id = uuid.uuid4().hex
    JOBS[job_id] = {"status": "running", "t": now}
    threading.Thread(target=run_json_job, args=(job_id, contents, token_steps, post), daemon=True).start()
    return jsonify({"job_id": job_id})


# =========================
# 기록 저장 (SQLite)
# =========================
# analyses : 분석 한 번 = 한 줄. AI 결과 전체(JSON)와 작은 사진을 같이 저장한다.
# mistakes : 그 분석에서 나온 자주 하는 실수. 실수 횟수와 실수 노트는 이 표에서 SQL로 바로 꺼낸다.
SCHEMA = """
CREATE TABLE IF NOT EXISTS analyses (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at      INTEGER NOT NULL,   -- 저장한 시각 (밀리초, 자바스크립트 Date와 같은 단위)
    verdict         TEXT,
    one_line        TEXT,
    problem         TEXT,
    primary_concept TEXT,
    data_json       TEXT NOT NULL,
    problem_thumb   BLOB,
    solution_thumb  BLOB
);
CREATE TABLE IF NOT EXISTS mistakes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    analysis_id INTEGER NOT NULL REFERENCES analyses(id),
    created_at  INTEGER NOT NULL,
    mistake     TEXT NOT NULL,
    step        TEXT,
    wrote       TEXT,
    why_wrong   TEXT,
    correct     TEXT
);
"""


def init_db():
    """기록 파일과 표를 만든다. 앱 폴더에 쓸 수 없으면 (맥 바탕화면 권한 등) 홈 폴더에 만든다."""
    global DB_PATH
    for path in (DB_PATH, os.path.join(os.path.expanduser("~"), "mongdang.db")):
        try:
            with closing(sqlite3.connect(path)) as con:
                con.executescript(SCHEMA)
            DB_PATH = path
            print("[몽당] 기록 파일:", path, flush=True)
            return
        except sqlite3.Error as e:
            print(f"[몽당] {path} 에 기록 파일을 만들 수 없어요 ({e})", flush=True)
    raise SystemExit("기록 파일(mongdang.db)을 만들 수 없습니다.")


@contextmanager
def db():
    """요청마다 새로 연결한다. 분석 결과는 다른 스레드에서 저장되기 때문에 연결을 함께 쓰지 않는다."""
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row  # 결과를 row["열 이름"] 으로 읽을 수 있게
    try:
        with con:  # 블록이 정상으로 끝나면 저장(commit), 중간에 오류가 나면 되돌림(rollback)
            yield con
    finally:
        con.close()


def save_record(con, data, thumbs):
    """분석 결과 하나를 저장하고 기록 번호를 돌려준다"""
    now = int(time.time() * 1000)
    cur = con.execute(
        "INSERT INTO analyses (created_at, verdict, one_line, problem, primary_concept, data_json, problem_thumb, solution_thumb)"
        " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (now, str(data.get("verdict", "")), str(data.get("one_line", "")), str(data.get("problem", "")),
         data["primary_concept"], json.dumps(data, ensure_ascii=False), thumbs["problem"], thumbs["solution"]))
    saved = set()
    for e in data.get("errors") or []:
        mistake = str(e.get("mistake") or "").strip()
        if mistake and mistake not in saved:  # 한 분석 안에서 같은 실수가 두 번 나와도 한 번만 센다
            saved.add(mistake)
            con.execute(
                "INSERT INTO mistakes (analysis_id, created_at, mistake, step, wrote, why_wrong, correct)"
                " VALUES (?, ?, ?, ?, ?, ?, ?)",
                (cur.lastrowid, now, mistake, *(str(e.get(k) or "") for k in ("step", "wrote", "why_wrong", "correct"))))
    return cur.lastrowid


def delete_record(con, analysis_id):
    con.execute("DELETE FROM mistakes WHERE analysis_id = ?", (analysis_id,))
    con.execute("DELETE FROM analyses WHERE id = ?", (analysis_id,))


def mistake_counts(con, data):
    """이 분석에 나온 실수가 지금까지 전체 기록에서 몇 번 나왔는지 {실수: 횟수}"""
    counts = {}
    for e in data.get("errors") or []:
        mistake = str(e.get("mistake") or "").strip()
        if mistake:
            counts[mistake] = con.execute("SELECT COUNT(*) FROM mistakes WHERE mistake = ?", (mistake,)).fetchone()[0]
    return counts


def known_mistakes():
    """AI에게 알려 줄 이전 실수 목록 (많이 나온 순, 최대 30개)"""
    with db() as con:
        rows = con.execute("SELECT mistake FROM mistakes GROUP BY mistake"
                           " ORDER BY COUNT(*) DESC, MAX(created_at) DESC LIMIT 30").fetchall()
    return [r["mistake"] for r in rows]


def save_after_analysis(data, thumbs, replace_id):
    """분석이 끝나면 바로 저장한다. 판독을 고쳐 다시 분석한 것이면 원래 기록은 지운다 (같은 풀이가 두 번 세어지지 않게).
    저장에 실패해도 분석 결과는 그대로 보여 준다."""
    data = normalize_analysis(data)
    try:
        with db() as con:
            if replace_id:
                delete_record(con, replace_id)
            history_id = save_record(con, data, thumbs)
            counts = mistake_counts(con, data)
        data.update(history_id=history_id, mistake_counts=counts)
    except Exception as e:
        print("[몽당] 기록 저장 실패:", repr(e)[:200], flush=True)
    return data


# =========================
# 주소 (라우트)
# =========================
@app.route("/")
def index():
    return render_template("index.html")  # templates/index.html


@app.route("/analyze", methods=["POST"])
def analyze():
    single = request.form.get("single") == "1"
    photos = [request.files.get("problem")] if single else [request.files.get("problem"), request.files.get("solution")]
    if not all(photos):
        return jsonify({"error": "문제 사진과 풀이 사진을 모두 올려주세요."}), 400
    try:
        imgs = [load_image(f) for f in photos]
    except Exception:
        return jsonify({"error": "이미지를 읽을 수 없어요. 다른 사진으로 시도해 주세요."}), 400
    corrections = parse_corrections(request.form.get("corrections"))
    replace_id = request.form.get("replace", type=int)  # 판독을 고쳐 다시 분석할 때, 바꿀 원래 기록 번호
    thumbs = {"problem": make_thumb(imgs[0]), "solution": make_thumb(imgs[1]) if len(imgs) > 1 else None}
    # 전에 찾은 자주 하는 실수를 같이 보내서, 같은 실수면 같은 문장으로 쓰게 한다 (반복 횟수를 세기 위해)
    prompt = build_prompt(single, corrections, known_mistakes())
    return start_job([prompt] + imgs, (12000, 20000), post=lambda data: save_after_analysis(data, thumbs, replace_id))


@app.route("/practice", methods=["POST"])
def practice():
    b = request.get_json(silent=True) or {}
    problem = str(b.get("problem") or "").strip()[:3000]
    if not problem:
        return jsonify({"error": "원래 문제 정보가 없어요."}), 400
    concepts = clean_list(b.get("concepts"), 3, 50)
    mistakes = clean_list(b.get("mistakes"), 3, 200)
    prompt = (PRACTICE_PROMPT
              .replace("__CONCEPTS__", ", ".join(concepts) or "(없음)")
              .replace("__MISTAKES__", "\n".join("- " + m for m in mistakes) or "(없음)")
              .replace("__PROBLEM__", problem))  # 문제 글은 맨 마지막에 넣는다 (문제 안의 글자가 다른 칸으로 바뀌지 않게)
    return start_job([prompt], (6000, 12000))


@app.route("/status/<job_id>")
def status(job_id):
    job = JOBS.get(job_id)
    if not job:
        return jsonify({"status": "error", "error": "작업을 찾을 수 없어요. 다시 시도해 주세요."})
    return jsonify({k: v for k, v in job.items() if k != "t"})


@app.route("/history")
def history():
    """내 흔적 화면에 필요한 것을 한 번에: 통계, 자주 하는 실수, 핵심 개념 순위, 지난 분석 목록"""
    with db() as con:
        total, right, wrong = con.execute(
            "SELECT COUNT(*), COALESCE(SUM(verdict = '정답'), 0), COALESCE(SUM(verdict = '오답'), 0) FROM analyses").fetchone()
        mistakes = con.execute(
            "SELECT mistake, COUNT(*) AS count, MAX(created_at) AS last FROM mistakes"
            " GROUP BY mistake ORDER BY count DESC, last DESC LIMIT 10").fetchall()
        # 핵심 개념만 센다 (함께 고른 관련 개념은 매번 조금씩 달라질 수 있어서 통계에서 뺌)
        concepts = con.execute(
            "SELECT primary_concept AS name, COUNT(*) AS count FROM analyses WHERE primary_concept != ''"
            " GROUP BY primary_concept ORDER BY count DESC LIMIT 6").fetchall()
        items = con.execute(
            "SELECT id, created_at, verdict, one_line FROM analyses ORDER BY created_at DESC LIMIT 100").fetchall()
    return jsonify({"total": total, "right": right, "wrong": wrong,
                    "mistakes": [dict(r) for r in mistakes],
                    "concepts": [dict(r) for r in concepts],
                    "items": [dict(r) for r in items]})


@app.route("/history/<int:hid>")
def history_one(hid):
    with db() as con:
        row = con.execute("SELECT data_json, solution_thumb IS NOT NULL AS has_solution FROM analyses WHERE id = ?",
                          (hid,)).fetchone()
        if not row:
            return jsonify({"error": "기록을 찾을 수 없어요."}), 404
        data = normalize_analysis(json.loads(row["data_json"]))
        data.update(history_id=hid, mistake_counts=mistake_counts(con, data))
    thumbs = {"problem": f"/thumb/{hid}/problem", "solution": f"/thumb/{hid}/solution" if row["has_solution"] else None}
    return jsonify({"data": data, "thumbs": thumbs})


@app.route("/history/<int:hid>", methods=["DELETE"])
def history_delete(hid):
    with db() as con:
        delete_record(con, hid)
    return jsonify({"ok": True})


@app.route("/thumb/<int:hid>/<kind>")
def thumb(hid, kind):
    if kind not in ("problem", "solution"):
        return "", 404
    with db() as con:
        row = con.execute(f"SELECT {kind}_thumb FROM analyses WHERE id = ?", (hid,)).fetchone()
    if not row or not row[0]:
        return "", 404
    return Response(row[0], mimetype="image/jpeg")


@app.route("/mistake-note")
def mistake_note():
    """자주 하는 실수 하나가 나온 문제를 최근 순으로 모두 모은다"""
    text = request.args.get("text", "").strip()
    with db() as con:
        rows = con.execute(
            "SELECT m.analysis_id AS id, m.created_at, m.step, m.wrote, m.why_wrong, m.correct, a.verdict, a.problem"
            " FROM mistakes m JOIN analyses a ON a.id = m.analysis_id"
            " WHERE m.mistake = ? ORDER BY m.created_at DESC", (text,)).fetchall()
    if not rows:
        return jsonify({"error": "이 실수가 나온 기록이 없어요."}), 404
    return jsonify({"text": text, "items": [dict(r) for r in rows]})


if __name__ == "__main__":
    init_db()
    # host="0.0.0.0" 으로 바꾸면 같은 와이파이의 폰에서도 접속 가능
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
