"""
몽당 진단 일관성 측정 스크립트
같은 문제·풀이 사진을 N번 분석해서, 개념/판정/자주 하는 실수가 얼마나 달라지는지 센다.

사용법 (GEMINI_API_KEY가 설정된 터미널에서):
    python measure_consistency.py 문제사진 풀이사진 --runs 5 --out before.json
    또는 같은 폴더에 22_9_21.png(문제), 22_9_21_X.jpeg(풀이)를 두고 그냥 실행 (실행 버튼도 가능)

- 앱 파일(mongdang.py)과 같은 폴더에 두고 실행한다.
- 앱의 실제 함수(load_image, build_prompt, generate_with_retry, parse_json, normalize_analysis)를 그대로 불러 쓴다.
  그래서 앱 코드를 고친 뒤 다시 돌리면 "고친 후" 결과가 된다.
- 이전 실수 목록(known_rules)은 넣지 않는다. 매 실행이 서로 영향을 주지 않게 하기 위해서다.
"""
import argparse
import collections
import importlib.util
import json
import os
import sys
import time


def load_app(path):
    spec = importlib.util.spec_from_file_location("mongdang_app", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # app.run()은 __main__일 때만 실행되므로 서버는 켜지지 않는다
    return mod


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("problem", nargs="?", default="22_9_21.png", help="문제 사진 경로 (기본: 22_9_21.png)")
    ap.add_argument("solution", nargs="?", default="22_9_21_X.jpeg", help="풀이 사진 경로 (기본: 22_9_21_X.jpeg)")
    ap.add_argument("--runs", type=int, default=5, help="반복 횟수 (기본 5)")
    ap.add_argument("--out", default="consistency_result.json", help="결과 저장 파일")
    ap.add_argument("--app", default="mongdang.py", help="앱 파일 경로")
    ap.add_argument("--wait", type=float, default=5, help="실행 사이 대기 초 (무료 한도 보호)")
    args = ap.parse_args()

    # 실행 버튼으로 돌려도 되도록, 상대 경로는 이 스크립트가 있는 폴더 기준으로 찾는다
    here = os.path.dirname(os.path.abspath(__file__))
    fix = lambda p: p if os.path.isabs(p) else os.path.join(here, p)
    args.problem, args.solution, args.app, args.out = map(fix, (args.problem, args.solution, args.app, args.out))
    # 윈도우는 확장자가 숨겨져 있어서 problem.png.png 처럼 저장되거나, 확장자가 jpg/png로 다를 수 있다.
    # 정확한 이름이 없으면 같은 폴더에서 같은 이름으로 시작하는 사진을 찾는다. (풀이 사진은 문제 후보에서 뺀다)
    def find_image(p, skip=None):
        if os.path.exists(p):
            return p
        stem = os.path.basename(p).split(".")[0].lower()
        folder = os.path.dirname(p)
        for f in sorted(os.listdir(folder)):
            if skip and os.path.join(folder, f) == skip:
                continue
            if f.lower().startswith(stem) and f.lower().rsplit(".", 1)[-1] in ("png", "jpg", "jpeg", "webp"):
                print(f"[안내] {os.path.basename(p)} 대신 {f} 를 사용합니다.")
                return os.path.join(folder, f)
        return None
    sol = find_image(args.solution)
    found = [find_image(args.problem, skip=sol), sol]
    if None in found:
        print("사진을 찾을 수 없어요. 이 폴더에 있는 파일:")
        for f in sorted(os.listdir(here)):
            print("  ", f)
        sys.exit("문제 사진은 22_9_21.png, 풀이 사진은 22_9_21_X.jpeg 로 두거나, 실행할 때 경로를 적어 주세요.")
    args.problem, args.solution = found

    if not os.path.exists(args.app):
        sys.exit(f"앱 파일을 찾을 수 없어요: {args.app}")
    m = load_app(args.app)

    with open(args.problem, "rb") as f1, open(args.solution, "rb") as f2:
        imgs = [m.load_image(f1), m.load_image(f2)]
    prompt = m.build_prompt(False, [], [])

    runs = []
    for i in range(1, args.runs + 1):
        print(f"[{i}/{args.runs}] 분석 중...", flush=True)
        t0 = time.time()
        row = {"run": i}
        try:
            resp = m.generate_with_retry([prompt] + imgs, deadline=time.time() + 200)
            data = m.normalize_analysis(m.parse_json(resp.text))
            row.update(
                ok=True,
                seconds=round(time.time() - t0, 1),
                verdict=data.get("verdict"),
                concepts=sorted(data["concepts"]),
                primary=data["primary_concept"],
                mistakes=[str(e.get("mistake", "")) for e in data.get("errors") or [] if e.get("mistake")],
                error_kinds=[str(e.get("kind", "")) for e in data.get("errors") or []],
                one_line=data.get("one_line"),
                ref_answer=(data.get("reference") or {}).get("answer"),
                ref_checks=(data.get("reference") or {}).get("key_checks"),
            )
        except Exception as e:
            row.update(ok=False, seconds=round(time.time() - t0, 1), error=repr(e)[:300])
        runs.append(row)
        if i < args.runs:
            time.sleep(args.wait)

    ok = [r for r in runs if r.get("ok")]
    concept_count = collections.Counter(c for r in ok for c in r["concepts"])
    concept_sets = collections.Counter(" + ".join(r["concepts"]) or "(없음)" for r in ok)
    verdicts = collections.Counter(r["verdict"] for r in ok)
    primaries = collections.Counter(r["primary"] for r in ok)

    print("\n================ 결과 ================")
    print(f"성공 {len(ok)}/{len(runs)}회")
    print(f"판정: {dict(verdicts)}")
    print(f"핵심 개념 종류: {len(primaries)}개  (1이면 매번 같음) {dict(primaries)}")
    print(f"나온 개념 종류: {len(concept_count)}개")
    for name, n in concept_count.most_common():
        print(f"  {name}: {n}회")
    print(f"개념 조합 종류: {len(concept_sets)}개  (1이면 매번 같음)")
    for combo, n in concept_sets.most_common():
        print(f"  [{n}회] {combo}")
    print("자주 하는 실수 문장:")
    for r in ok:
        print(f"  {r['run']}회차: {r['mistakes'] or '(없음)'}")
    print("한 줄 진단:")
    for r in ok:
        print(f"  {r['run']}회차: {r['one_line']}")
    if any(r.get("ref_checks") for r in ok):
        print("AI가 직접 푼 결과 (정답 / 핵심 확인):")
        for r in ok:
            print(f"  {r['run']}회차: 정답 {r.get('ref_answer')} / {r.get('ref_checks')}")
    print("오류 종류:")
    for r in ok:
        print(f"  {r['run']}회차: {r['error_kinds']}")
    if ok:
        print(f"평균 응답 시간: {sum(r['seconds'] for r in ok) / len(ok):.1f}초")
    for r in runs:
        if not r.get("ok"):
            print(f"  {r['run']}회차 실패: {r['error']}")

    summary = {
        "runs": args.runs,
        "success": len(ok),
        "verdicts": dict(verdicts),
        "distinct_primary": len(primaries),
        "primary_count": dict(primaries),
        "distinct_concepts": len(concept_count),
        "concept_count": dict(concept_count),
        "distinct_concept_sets": len(concept_sets),
        "concept_sets": dict(concept_sets),
    }
    payload = json.dumps({"summary": summary, "runs": runs}, ensure_ascii=False, indent=2)
    for path in (args.out, os.path.join(os.path.expanduser("~"), os.path.basename(args.out))):
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(payload)
            print(f"\n자세한 결과를 {path} 에 저장했어요.")
            break
        except OSError as e:
            print(f"\n{path} 에 저장하지 못했어요 ({e.strerror}). 다른 위치에 시도합니다.")
    else:
        print("\n파일 저장에 실패했어요. 위 화면 결과를 그대로 복사해 두세요.")


if __name__ == "__main__":
    main()
