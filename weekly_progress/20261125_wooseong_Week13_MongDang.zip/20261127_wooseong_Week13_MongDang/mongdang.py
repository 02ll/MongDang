"""
몽당 - 손글씨 수학 풀이를 읽고 어디서 막혔는지 짚어 주는 웹앱 (Flask + Gemini)
초등학생부터 대학생까지: 문제의 학교급을 AI가 판단해서 말투와 개념, 연습 문제 수준을 맞춘다.

폴더 구성
  mongdang.py              서버 (이 파일, 파이썬만)
  templates/index.html     화면 뼈대 (HTML)
  static/style.css         화면 꾸밈 (CSS)
  static/app.js            화면 동작 (JavaScript): 업로드, 결과, 내 흔적, 실수 노트
  static/figure.js         연습 문제 그림 그리기: AI가 준 설계도로 그래프·도형·표를 그림
  measure_consistency.py   진단 일관성 측정 (9주차)
  check_practice.py        연습 문제 품질 확인: 실제 AI로 여러 번 만들어 보고 결과를 저장 (13주차)
  mongdang.db              기록 파일 (처음 실행할 때 자동으로 생김)

이 파일의 순서
  1. 설정          모델, API 키, 기록 파일 위치
  2. AI 호출       서버가 붐비면 모델을 바꿔 가며 다시 시도
  3. 프롬프트      개념 목록(학교급별), 풀이 분석, 연습 문제
  4. AI 응답 정리  개념 정렬, JSON 읽기
  5. 요청 값 정리  사진, 판독 정정
  6. 작업          분석은 오래 걸려서 백그라운드로 돌리고, 브라우저는 /status 로 결과를 확인
  7. 기록 저장     SQLite (analyses, mistakes 표)
  8. 주소          /analyze, /practice, /status, /history, /mistake-note

실행: GEMINI_API_KEY 를 설정한 터미널에서 이 폴더로 이동한 뒤  python mongdang.py  →  http://127.0.0.1:5000
"""
import os
import io
import json
import math
import random
import re
import sqlite3
import time
import threading
import uuid
from contextlib import closing, contextmanager
from flask import Flask, request, jsonify, Response, render_template
from google import genai
from google.genai import types
from PIL import Image, ImageOps

# =========================
# 설정
# =========================
MODEL_NAME = os.environ.get("MONGDANG_MODEL", "gemini-3.6-flash")

api_key = os.environ.get("GEMINI_API_KEY")
if not api_key:
    raise SystemExit("GEMINI_API_KEY 환경변수가 설정되지 않았습니다.")

client = genai.Client(api_key=api_key, http_options=types.HttpOptions(timeout=90000))
app = Flask(__name__)

# 주 모델이 붐비면 순서대로 넘어갈 예비 모델들
FALLBACK_MODELS = [m.strip() for m in os.environ.get(
    "MONGDANG_FALLBACKS", "gemini-3.8-flash").split(",") if m.strip()]
MODEL_CHAIN = [MODEL_NAME] + [m for m in FALLBACK_MODELS if m != MODEL_NAME]
BUSY_WORDS = ("503", "UNAVAILABLE", "429", "RESOURCE_EXHAUSTED", "overloaded", "high demand", "500", "INTERNAL", "DEADLINE", "timed out", "Timeout", "timeout", "ReadTimeout", "ConnectError", "disconnected")

# 작업 하나에 쓸 수 있는 전체 시간 (프론트 대기 한도 260초보다 짧게)
JOB_TIME_BUDGET = 220

# AI가 답하기 전에 "생각"할 수 있는 분량.
# 1024로 제한했을 때 어려운 문제에서 AI가 문제를 끝까지 풀지 못하고 진단이 매번 달라졌다 (측정 결과 9회 중 약 3회만 정확).
THINKING_BUDGET = int(os.environ.get("MONGDANG_THINKING", "4096"))
SEED = 7  # 같은 입력에는 최대한 같은 답이 나오도록 고정

# 분석 기록을 저장할 SQLite 파일 (앱 파일과 같은 폴더). 브라우저 캐시를 지워도 기록이 남는다.
DB_PATH = os.environ.get("MONGDANG_DB") or os.path.join(os.path.dirname(os.path.abspath(__file__)), "mongdang.db")


# =========================
# AI 호출
# =========================
def make_config(with_thinking=True, max_tokens=12000, varied=False):
    """varied=True 는 연습 문제용: 누를 때마다 다른 문제가 나오도록 seed 를 고정하지 않고 temperature 를 조금 준다.
    진단(분석)은 같은 사진에 같은 결과가 나와야 해서 temperature 0, seed 고정 그대로 둔다."""
    kw = dict(response_mime_type="application/json", temperature=0.7 if varied else 0, max_output_tokens=max_tokens)
    if with_thinking:
        try:
            kw["thinking_config"] = types.ThinkingConfig(thinking_budget=THINKING_BUDGET)
        except Exception:
            pass
    if varied:
        return types.GenerateContentConfig(**kw)
    try:
        return types.GenerateContentConfig(seed=SEED, **kw)
    except Exception:
        # seed를 지원하지 않는 라이브러리 버전이면 seed 없이
        return types.GenerateContentConfig(**kw)


_discovered = None


def model_chain():
    """설정한 모델(주 모델 + 예비 모델) 뒤에, 이 API 키로 실제 쓸 수 있는 다른 Flash 모델을 붙인다.
    모델 이름을 짐작해서 적는 대신, 서버에 목록을 물어봐서 확인된 것만 쓴다. (처음 한 번만 조회)"""
    global _discovered
    if _discovered is None:
        _discovered = []
        try:
            for m in client.models.list():
                name = (m.name or "").split("/")[-1]
                actions = getattr(m, "supported_actions", None) or []
                if ("flash" in name and "generateContent" in actions
                        and not any(w in name for w in ("lite", "image", "tts", "live", "audio", "embedding"))):
                    _discovered.append(name)
            _discovered.sort(reverse=True)  # 버전 숫자가 높은 것부터
            print(f"[몽당] 사용 가능한 Flash 모델: {_discovered}", flush=True)
        except Exception as e:
            print(f"[몽당] 모델 목록 조회 실패 (설정한 모델만 사용): {str(e)[:120]}", flush=True)
    return MODEL_CHAIN + [m for m in _discovered if m not in MODEL_CHAIN]


def generate_with_retry(contents, max_tokens=12000, deadline=None, varied=False):
    """모델 호출. 서버가 붐비면(503 등) 모델을 번갈아 바꿔 가며, 한 바퀴 돌 때마다 점점 길게 쉬었다가 다시 시도한다.
    - 한 모델이 붐비는 동안 같은 모델만 계속 두드리지 않고 다른 모델로 바로 넘어간다.
    - 대기 시간은 2초, 4초, 8초, 16초... 로 늘리고(최대 20초), 여러 요청이 동시에 몰리지 않게 약간의 무작위 시간을 더한다.
    - deadline(시각)이 지나면 멈춘다."""
    if deadline is None:
        deadline = time.time() + 170
    chain = model_chain()
    no_thinking = set()   # 생각 설정을 거부한 모델
    dead = set()          # 이 키로는 없는 모델 (NOT_FOUND)
    last_err = None
    rnd = 0
    while time.time() < deadline:
        alive = [m for m in chain if m not in dead]
        if not alive:
            break
        for model in alive:
            if time.time() >= deadline:
                break
            with_thinking = model not in no_thinking
            try:
                print(f"[몽당] {model} 시도 (라운드 {rnd+1}, thinking={with_thinking}, max={max_tokens})", flush=True)
                t0 = time.time()
                r = client.models.generate_content(
                    model=model, contents=contents,
                    config=make_config(with_thinking=with_thinking, max_tokens=max_tokens, varied=varied),
                )
                print(f"[몽당] {model} 성공 {time.time()-t0:.1f}초", flush=True)
                return r
            except Exception as e:
                last_err = e
                msg = str(e)
                print(f"[몽당] {model} 실패: {msg[:200]}", flush=True)
                if "API_KEY_INVALID" in msg or "API key not valid" in msg:
                    raise  # 키가 틀리면 다른 모델로 바꿔도 소용없다 (12주차 테스트에서 발견)
                if with_thinking and ("thinking" in msg.lower() or "INVALID_ARGUMENT" in msg):
                    no_thinking.add(model)   # 다음 라운드에선 생각 설정 없이
                    continue
                if "NOT_FOUND" in msg or "404" in msg:
                    dead.add(model)
                    continue
                if not any(w in msg for w in BUSY_WORDS):
                    raise
        # 모든 모델이 한 바퀴 다 실패 → 점점 길게 쉬고 다시
        wait = min(20, 2 * 2 ** rnd) + random.uniform(0, 1)
        if time.time() + wait >= deadline:
            break
        print(f"[몽당] 모든 모델이 붐빔. {wait:.1f}초 쉬고 다시 시도", flush=True)
        time.sleep(wait)
        rnd += 1
    raise last_err or TimeoutError("분석 시간이 너무 오래 걸렸어요")


# =========================
# 프롬프트
# =========================
IMAGES_TWO = "두 장의 이미지가 주어진다. 첫 번째 = 수학 문제, 두 번째 = 학생이 직접 쓴 풀이."
IMAGES_ONE = ("한 장의 이미지가 주어진다. 이 이미지 안에 수학 문제와 학생이 직접 쓴 풀이가 함께 있다. "
              "인쇄된 글씨(문제 영역)는 문제로, 그 위나 옆에 쓴 손글씨는 학생의 풀이로 구분해서 읽는다. "
              "문제에 원래 있던 표시와 학생이 쓴 흔적이 헷갈리면 확정하지 말고 \"판독이 불확실함\"이라고 쓴다.")

# 표준 개념 목록: 분석 프롬프트와 코드(개념 정렬)가 함께 쓴다.
# 학교급 순서(초등 → 중등 → 고등 → 대학)이고, 같은 학교급 안에서는 교육과정 순서다.
# 중학교와 고등학교에서 모두 배우는 것(인수분해, 경우의 수)은 처음 배우는 학교급에 한 번만 둔다.
# 고등 개념 이름은 12주차까지 쓰던 이름 그대로다 (지난 기록의 통계가 끊기지 않게).
LEVELS = ("초등", "중등", "고등", "대학")
CONCEPTS_BY_LEVEL = {
    "초등": ["자연수의 사칙연산", "혼합 계산", "약수와 배수", "약분과 통분", "분수의 계산", "소수의 계산",
            "규칙과 대응", "비와 비율", "비례식과 비례배분", "각도와 평면도형", "도형의 둘레와 넓이",
            "원의 둘레와 넓이", "직육면체의 겉넓이와 부피", "단위와 어림", "자료와 그래프", "평균과 가능성"],
    "중등": ["소인수분해", "정수와 유리수", "문자와 식", "일차방정식", "좌표평면과 그래프", "기본 도형과 작도",
            "평면도형의 성질", "입체도형의 겉넓이와 부피", "자료의 정리와 해석", "순환소수", "지수법칙과 식의 계산",
            "일차부등식", "연립일차방정식", "일차함수와 그래프", "삼각형의 성질과 합동", "사각형의 성질",
            "도형의 닮음", "피타고라스 정리", "경우의 수", "확률의 뜻과 계산", "제곱근과 실수", "곱셈 공식",
            "인수분해", "이차방정식의 풀이", "이차함수의 그래프", "삼각비", "원의 성질", "대푯값과 산포도", "상관관계"],
    "고등": ["다항식의 연산", "나머지정리와 인수정리", "복소수", "이차방정식의 근과 계수의 관계", "판별식",
            "이차함수와 직선의 위치 관계", "이차함수의 최대최소", "여러 가지 방정식", "부등식",
            "절댓값 방정식과 부등식", "집합의 연산", "명제와 조건", "함수의 정의와 그래프", "합성함수", "역함수",
            "유리함수와 무리함수", "평행이동과 대칭이동", "순열과 조합", "확률의 기본 성질", "조건부확률", "통계",
            "지수와 로그의 계산", "지수함수", "로그함수", "지수함수와 로그함수의 그래프", "지수방정식과 로그방정식",
            "삼각함수의 정의", "삼각함수의 그래프", "삼각방정식과 부등식", "사인법칙과 코사인법칙", "등차수열",
            "등비수열", "수열의 합", "점화식", "수학적 귀납법", "함수의 극한", "함수의 연속", "미분계수와 도함수",
            "접선의 방정식", "함수의 증감과 극값", "부정적분", "정적분", "정적분과 넓이", "수열의 극한", "급수",
            "여러 가지 미분법", "여러 가지 적분법", "이차곡선", "벡터", "공간도형"],
    "대학": ["극한의 엄밀한 정의", "급수의 수렴 판정", "테일러 급수", "편미분", "중적분", "벡터 미적분", "미분방정식",
            "행렬과 행렬식", "연립일차방정식과 가우스 소거법", "벡터공간과 기저", "선형변환", "고유값과 고유벡터",
            "확률변수와 확률분포", "논리와 증명"],
    "기타": ["기타 계산 실수"],
}
STANDARD_CONCEPTS = [c for names in CONCEPTS_BY_LEVEL.values() for c in names]
CONCEPT_ORDER = {name: i for i, name in enumerate(STANDARD_CONCEPTS)}
CONCEPT_LIST_TEXT = "\n".join(f"{level}: {', '.join(names)}" for level, names in CONCEPTS_BY_LEVEL.items())


PROMPT = """
너는 수학 학습 분석 AI인 몽당이다.
__IMAGES__
정답과 해설을 주는 것이 목적이 아니다. 학생의 실제 풀이 흔적을 보고 어디서 왜 막혔는지 진단한다.

원칙:
- 학생의 풀이를 실제로 분석한 결과만 말한다. 정확하면 정확하다고 인정한다.
- 손글씨가 불분명하면 확정하지 말고 "판독이 불확실함"이라고 쓴다.
- 오류가 명확하지 않으면 추측해서 단정하지 않는다.
- 학생에게 보여 줄 문장은 짧고 쉽게 쓴다. 같은 내용을 여러 칸에 되풀이하지 않는다.
- 학생에게 보여 줄 문장(steps 의 comment, errors, abandoned 의 comment, one_line)의 말투와 용어는 level 에 맞춘다.
  · 초등: 초등학생이 읽을 수 있는 쉬운 말로 짧게 쓴다. 초등학교에서 배우지 않는 용어는 쓰지 않고 풀어서 말한다.
  · 중등: 중학교 교과서 용어를 쓴다.
  · 고등: 고등학교 교과서 용어를 쓴다.
  · 대학: 전공 용어를 그대로 쓰고, 필요하면 정의나 정리 이름으로 짚어 준다.
- steps 의 student_wrote 에는 학생이 쓴 내용을 해석하지 말고 읽은 그대로 옮긴다. (학생이 판독 결과를 확인하고 고칠 수 있도록)
- steps 의 comment 는 한 줄로 쓴다. 틀린 단계는 무엇이 틀렸는지만 짧게 쓰고, 왜 틀렸는지와 고치는 법은 errors 에만 쓴다.

[진단 순서] 반드시 이 순서로 판단하고, JSON도 이 순서대로 채운다.
0. level: 문제를 보고 학교급을 정한다. 초등(초등학교 수학), 중등(중학교 수학), 고등(고등학교 수학), 대학(대학 수학) 중 하나.
   여러 학교급에 걸치면 문제를 푸는 데 꼭 필요한 개념 중 가장 높은 학교급으로 정한다.
1. reference: 학생 풀이를 평가하기 전에 먼저 문제를 직접 끝까지 푼다.
   - 그림이나 그래프의 모양만 보고 함수 사이의 관계(역함수, 대칭, 평행이동, 접함 등)를 짐작하지 않는다. 반드시 식을 직접 변형하거나 대입해서 확인하고, 그 확인 과정을 key_checks 에 쓴다.
   - 정답까지 구한 뒤, 검산한다.
2. steps, errors: 학생 풀이의 각 단계를 reference 와 하나씩 비교해 판단한다. reference 와 다르게 판단할 근거가 없으면 학생의 단계를 맞다고 하지 않는다.
3. 나머지 칸(verdict, one_line, concepts)은 errors 에서 내린 판단을 요약만 한다. 새로운 판단을 하지 않는다.
   - 한 칸에서 틀렸다고 한 내용을 다른 칸에서 맞았다고 하지 않는다. (예: errors 에서 어떤 관계를 잘못 판단했다고 했다면, one_line 에서 그 관계를 "잘 활용했다"고 하지 않는다.)
4. kind 구분: 그 단계의 근거가 된 수학적 사실이나 관계를 잘못 알았으면 "개념 오류", 방법과 근거는 맞는데 계산만 틀렸으면 "계산 실수".

[자주 하는 실수]
- 오류마다 학생이 "자주 하는 실수"를 찾아 errors.mistake 에 쓴다.
  자주 하는 실수 = 학생이 맞다고 믿고 일관되게 적용하는 잘못된 방식. 개념 이름이 아니라, 학생이 실제로 하는 행동을 "~한다" 형태의 한 문장으로 쓴다.
  예: "$(a+b)^2$ 를 $a^2+b^2$ 로 전개한다", "부등식 양변에 음수를 곱해도 부등호 방향을 그대로 둔다", "$a^m a^n$ 을 $a^{mn}$ 으로 계산한다"
- 다른 문제에도 그대로 적용될 수 있도록 이 문제의 숫자가 아니라 일반적인 형태로 쓴다.
- 숫자를 잘못 옮겨 적거나 덧셈을 한 번 틀린 것처럼 반복될 만한 실수가 아니라 우연한 실수면 mistake 는 빈 문자열로 둔다. 억지로 만들지 않는다.
__KNOWN_RULES__
[지우고 버린 흔적]
- 지우개 자국, 줄 그어 지운 부분, 쓰다 만 식, 여백의 계산처럼 최종 풀이에 쓰이지 않은 흔적을 찾아 abandoned 에 쓴다.
- 이미지에 실제로 보이는 것만 쓴다. 없으면 빈 배열로 둔다. 흐려서 내용을 읽을 수 없으면 what 에 "판독이 불확실함"이라고 쓴다.
- 각 흔적의 방향이 맞았는지(direction) 판단한다. comment 에는 어떤 접근이었는지 쓰고, 버린 시도가 사실 맞는 방향이었다면 반드시 그렇게 말하고 왜 버렸을지(추정이면 추정이라고 표시)와 계속했다면 어떻게 됐을지를 쓴다.

[개념]
- 학생의 오류나 풀이 습관과 직접 관련된 개념만 최대 3개 고른다. 문제에 쓰인 개념을 전부 나열하지 않는다.
- 학생이 잘못 알고 있던 수학적 사실이 속한 가장 기초 단원은 반드시 포함한다.
- 이름은 아래 [표준 개념 목록]에서 가장 가까운 것을 그대로 고른다. 목록에 정말 없을 때만 교과서 단원 이름 형태로 짧게 새로 쓴다.
- 목록은 학교급 순서다. 학생이 잘못 알고 있던 사실이 문제보다 아래 학교급에서 배우는 것이면 그 학교급의 개념을 고른다.
  (예: 고등 문제에서 분수끼리 더할 때 분모끼리 더했다면 초등의 "분수의 계산")

[표준 개념 목록] (학교급: 개념, …)
__CONCEPT_LIST__
- 모든 수식은 LaTeX. 인라인은 $...$ 만 사용한다. ($$ 는 쓰지 않는다.)
- JSON 문자열 안의 백슬래시는 반드시 두 번 쓴다. 예: "$\\\\frac{1}{2}$"

반드시 아래 JSON 형식으로만 답한다. 다른 글은 쓰지 않는다.
{
  "problem": "문제 내용 정리 (조건, 선택지 포함)",
  "level": "초등" | "중등" | "고등" | "대학",
  "reference": {
    "key_checks": ["문제를 푸는 데 결정적인 관계·조건을 식으로 직접 확인한 결과 (한 항목에 한 가지)"],
    "approach": "올바른 풀이의 핵심 흐름 2~4문장",
    "answer": "정답 (구할 수 없으면 판단 불가)"
  },
  "steps": [
    {"title": "단계 이름", "student_wrote": "학생이 쓴 내용", "status": "ok" | "error" | "unclear", "comment": "한 줄 코멘트 (틀린 단계는 무엇이 틀렸는지만)"}
  ],
  "errors": [
    {"step": "오류 단계", "kind": "계산 실수" | "개념 오류", "wrote": "학생이 쓴 내용", "why_wrong": "무엇이 왜 잘못됐나", "correct": "이렇게 고치면 된다", "mistake": "자주 하는 실수 한 문장 또는 빈 문자열"}
  ],
  "abandoned": [
    {"where": "흔적의 위치 (예: 오른쪽 여백, 셋째 줄 위 줄 그은 부분)", "what": "남아 있는 내용을 읽은 그대로", "direction": "맞는 방향" | "틀린 방향" | "판단 불가", "comment": "어떤 접근이었고, 왜 버렸을지, 계속했다면 어땠을지"}
  ],
  "verdict": "정답" | "오답" | "판단 불가능",
  "one_line": "학생에게 건네는 핵심 피드백 1~2문장 (errors 의 판단과 일치해야 함)",
  "concepts": ["개념 이름"]
}
errors, abandoned, concepts 는 해당 없으면 빈 배열로 둔다.
"""

KNOWN_RULES_NOTE = """- 아래는 이 학생에게서 이전에 발견된 자주 하는 실수다. 이번 오류가 이 중 하나와 같은 실수면 mistake 에 그 문장을 글자 하나 바꾸지 말고 그대로 쓴다. (같은 실수가 몇 번 반복되는지 세기 위해서다.) 다른 실수면 새로 쓴다. 억지로 맞추지 않는다.
"""

CORRECTION_NOTE = """
[학생의 판독 정정]
이전 분석에서 AI가 손글씨를 잘못 읽은 부분을 학생이 직접 고쳤다.
아래 정정 내용을 학생이 실제로 쓴 것으로 간주하고 처음부터 다시 분석한다. 이미지와 달라 보여도 정정 내용을 우선한다.
"""

PROMPT = PROMPT.replace("__CONCEPT_LIST__", CONCEPT_LIST_TEXT)

# 연습 문제: 결과 화면과 실수 노트가 함께 쓴다
PRACTICE_PROMPT = """
너는 수학 학습 도우미 몽당이다. 학생이 아래 문제를 풀었다. (원래 문제 사진이 함께 있으면 그림·그래프·표가 있었는지도 본다)

[원래 문제]
__PROBLEM__

[학교급]
__LEVEL__

[관련 개념]
__CONCEPTS__

[학생이 자주 하는 실수 (학생이 맞다고 믿고 쓰는 잘못된 방식)]
__MISTAKES__

이 학생을 위한 연습 문제 2개를 만든다.
- 자주 하는 실수가 있으면 두 문제를 짝으로 만든다. 학생이 "이번엔 그 방식을 써도 되는가"를 스스로 판단하게 하기 위해서다.
  · 실수 문제: 그 실수대로 풀면 반드시 틀린 답이 나오고, 올바르게 풀어야만 정답이 나오는 문제. 실수대로 해도 우연히 정답이 나오면 안 된다.
    trap 에 그 실수대로 풀면 나오는 오답과 이유를 쓰고, pair 는 빈 문자열로 둔다.
  · 짝 문제: 겉보기 상황은 실수 문제와 비슷하지만, 이번에는 그 방식이 실제로 성립해서 써도 되는 문제.
    trap 은 빈 문자열로 두고, pair 에 실수 문제와 무엇이 달라서 이번에는 되는지를 쓴다.
  · 문제 글과 hint 에는 짝이라는 것이나 그 실수를 드러내지 않는다.
  · pair 는 "이 문제는"으로 시작해서, 이번에는 왜 그 방식이 성립하는지 쓴다. 다른 문제를 번호로 부르지 않는다.
  · 그 방식이 성립하는 경우를 만들 수 없는 실수라면, 두 문제 모두 실수 문제로 만들고 pair 는 빈 문자열로 둔다.
- 자주 하는 실수가 없으면 trap 과 pair 는 빈 문자열로 두고, 같은 개념을 다른 각도에서 묻는다. 관련 개념도 없으면(정답을 맞힌 경우) 같은 단원에서 한 단계 어렵게 만든다.
- 원래 문제에서 숫자만 바꾼 문제는 만들지 않는다. 난이도는 원래 문제와 비슷하게 한다.
- 연습 문제는 [학교급]에서 배우는 내용 안에서 만들고, 문제·힌트·풀이의 말투와 용어도 그 학교급에 맞춘다.
  (초등이면 초등학교에서 배우지 않는 문자나 용어를 쓰지 않는다.)
- hint 는 막혔을 때 시작할 첫 계산만 짚는다. 예: "점 A의 좌표부터 구해 보세요."
  그 실수를 피하는 방법이나 확인할 것("○○가 성립하는지 확인해 보세요", "두 식의 관계를 직접 구해 비교해 보세요")을 쓰면
  함정을 알려 주는 것이라 안 된다. 실수 문제와 짝 문제의 hint 는 같은 방식으로 써서, hint 만 보고 둘을 구분할 수 없게 한다.
- 정답은 하나로 확정되어야 한다. 직접 풀어서 정답이 맞는지 검산하고, 실수 문제는 그 실수대로 풀면 정말 다른 답이 나오는지, 짝 문제는 그 방식을 써도 정말 같은 답이 나오는지도 검산한다.
- 모든 수식은 LaTeX. 인라인은 $...$ 만 사용한다.
- JSON 문자열 안의 백슬래시는 반드시 두 번 쓴다. 예: "$\\\\frac{1}{2}$"

[그림·그래프·표]
- 먼저 원래 문제 사진에 그래프·도형·표가 있었는지 보고 original_figure 에 true/false 로 쓴다.
- original_figure 가 true 이면 연습 문제 두 개 모두 figure 를 넣는다.
- false 이면, 시험·교과서 문제처럼 그래프·도형·표가 있어야 자연스러운 문제일 때만 figure 를 넣는다. 필요 없으면 null 로 둔다. 억지로 넣지 않는다.
- 특히 학생의 실수가 그래프나 도형을 보고 판단하다 생긴 것이면, 연습 문제도 그래프나 도형을 보고 판단하게 만든다.
- 그림을 직접 그리지 않는다. 아래 형식의 설계도(함수식, 좌표, 표 내용)만 쓰면 화면에서 그대로 정확하게 그린다.
- 설계도는 문제 조건과 정확히 맞아야 한다. 좌표와 함수식은 조건을 만족하는 실제 값으로 쓰고, 그린 뒤의 모습이 문제와 맞는지 확인한다.
- 문제에서 구해야 하는 값이 그래프에 필요하면 실제 정답 값을 넣어 그리되, 그 값을 그림 속 글자로 적지 않는다.
- 그래프의 expr 는 x 에 대한 식으로 쓴다. 곱셈은 *, 거듭제곱은 ^, 로그는 log(x, 밑), 자연로그는 log(x), 제곱근은 sqrt(x), 세제곱근은 cbrt(x), 절댓값은 abs(x), 삼각함수는 sin(x) cos(x) tan(x), 원주율은 pi, 자연상수는 e. 다른 문자(a, k 등)는 쓰지 않는다.
- x, y 범위는 문제에서 중요한 부분(교점, 점근선 근처 등)이 잘 보이게 잡는다.
- 그림 속 글자(label, text)는 짧게 쓰고 수식은 $...$ 로 쓴다. 점 이름(name)은 A, B, P 처럼 영문 대문자로 쓴다.
- 곡선 위의 점은 그 곡선의 식에 x 를 넣어 계산한 y 값을 정확히 쓴다. (화면에서 다시 계산해 보고, 어긋나면 문제를 새로 만든다)
- 필요한 것만 쓴다:
  · 점근선이나 가로·세로 보조선은 lines 에 {"x": 3} 또는 {"y": 1} 로 쓴다. (기본은 점선)
  · 정적분 넓이처럼 칠해야 할 영역은 regions 에 쓴다. between 은 [위쪽 곡선 번호, 아래쪽 곡선 번호] 이고 아래쪽이 x축이면 "x축". 곡선 번호는 functions 순서대로 0부터.
  · 그림에 이름 없이 선의 끝점으로만 쓸 점(수선의 발, 보조선 끝 등)은 "hidden": true 로 둔다.
  · 도형의 각은 angles 에 꼭짓점(at)과 양쪽 점(from, to)으로 쓴다. 직각이면 "right": true, 각에 이름을 붙이면 text.

__AVOID__반드시 아래 JSON 형식으로만 답한다. 다른 글은 쓰지 않는다.
{
  "original_figure": false,
  "problems": [
    {"question": "문제", "figure": null, "hint": "막힐 때 볼 짧은 힌트", "answer": "정답", "trap": "그 실수대로 풀면 나오는 오답과 이유, 또는 빈 문자열", "pair": "이 문제는 무엇이 달라서 그 방식이 성립하는지, 또는 빈 문자열", "solution": "핵심만 담은 짧은 풀이"}
  ]
}
figure 는 null 이거나 아래 셋 중 하나다.
- 그래프: {"type": "graph", "x": [x최소, x최대], "y": [y최소, y최대],
          "functions": [{"expr": "2^x", "label": "$y=2^x$"}],
          "points": [{"name": "A", "x": 1, "y": 2}],
          "segments": [{"from": "A", "to": "B", "dashed": true}],
          "lines": [{"x": 3}], "regions": [{"between": [0, "x축"], "x": [1, 2]}],
          "texts": [{"x": 3, "y": 1, "text": "$k$"}]}
- 도형: {"type": "geometry",
          "points": [{"name": "A", "x": 0, "y": 3}, {"name": "B", "x": -2, "y": 0}, {"name": "C", "x": 2, "y": 0}],
          "segments": [{"from": "A", "to": "B", "dashed": false}],
          "circles": [{"center": "O", "radius": 3}],
          "angles": [{"at": "B", "from": "A", "to": "C", "text": "$\\\\theta$"}],
          "texts": [{"x": -1.3, "y": 1.6, "text": "$3$"}]}
- 표: {"type": "table", "rows": [["$x$", "$1$", "$2$", "$3$"], ["$f(x)$", "$2$", "$4$", "$8$"]]}
"""


AVOID_NOTE = "[이미 낸 연습 문제]\n__LIST__\n위 문제들과 함수, 숫자, 묻는 것이 겹치지 않게 새로 만든다.\n\n"


def build_practice_prompt(problem, concepts, mistakes, avoid=(), level=""):
    avoid_block = AVOID_NOTE.replace("__LIST__", "\n".join("- " + q for q in avoid)) if avoid else ""
    return (PRACTICE_PROMPT
            .replace("__AVOID__", avoid_block)
            .replace("__LEVEL__", level if level in LEVELS else "(모름: 원래 문제를 보고 맞춘다)")
            .replace("__CONCEPTS__", ", ".join(concepts) or "(없음)")
            .replace("__MISTAKES__", "\n".join("- " + m for m in mistakes) or "(없음)")
            .replace("__PROBLEM__", problem))  # 문제 글은 맨 마지막에 넣는다 (문제 안의 글자가 다른 칸으로 바뀌지 않게)


def build_prompt(single, corrections, known_rules=None):
    p = PROMPT.replace("__IMAGES__", IMAGES_ONE if single else IMAGES_TWO)
    block = KNOWN_RULES_NOTE + "".join(f"  - {r}\n" for r in known_rules) if known_rules else ""
    p = p.replace("__KNOWN_RULES__\n", block)
    if corrections:
        lines = "\n".join(
            f'- 단계 "{c["title"]}": AI가 "{c["read"]}"(으)로 읽음 → 학생 정정: "{c["wrote"]}"'
            for c in corrections)
        p += CORRECTION_NOTE + lines + "\n위 JSON 형식 규칙은 그대로 지킨다.\n"
    return p


# =========================
# AI 응답 정리
# =========================
def normalize_analysis(data):
    """AI 응답을 화면과 저장에 쓰기 전에 정리한다.
    1) 형식 맞추기: AI가 목록 칸을 글자나 null로 주거나, 목록 안에 객체 대신 글자를 넣어도 화면이 깨지지 않게 한다.
    2) 개념 정렬: 개념을 학교급·교육과정 순서로 정렬하고, 맨 앞(가장 기초) 개념을 핵심 개념으로 정한다.
       AI가 함께 고르는 개념은 매번 조금씩 달라질 수 있지만, 핵심 개념은 이 규칙으로 정해져서 통계가 흔들리지 않는다."""
    for key in ("steps", "errors", "abandoned"):
        items = data.get(key)
        data[key] = [x for x in items if isinstance(x, dict)] if isinstance(items, list) else []
    for key in ("problem", "one_line"):
        data[key] = str(data.get(key) or "")
    if data.get("verdict") not in ("정답", "오답", "판단 불가능"):
        data["verdict"] = "판단 불가능"
    if data.get("level") not in LEVELS:  # 학교급을 모르거나 이상한 값이면 비워 둔다 (화면에 표시 안 함)
        data["level"] = ""
    names = []
    for c in data.get("concepts") or []:
        name = str(c.get("name", "") if isinstance(c, dict) else c).strip()  # 10주차 초기 기록은 {"name": ...} 형태
        if name and name not in names:
            names.append(name)
    names.sort(key=lambda n: CONCEPT_ORDER.get(n, len(CONCEPT_ORDER)))  # 목록에 없는 이름은 뒤로
    data["concepts"] = names
    data["primary_concept"] = names[0] if names else ""
    return data


# 연습 문제 그림: AI가 준 설계도를 그리기 전에 검사한다. 형식이 이상하면 그림 없이 문제만 보여 준다.
POINT_NAME = re.compile(r"^[A-Z][A-Za-z0-9']{0,3}$")          # A, B, P1, A'
EXPR_CHARS = re.compile(r"^[0-9a-z+\-*/^().,\s]{1,80}$")      # 숫자, 소문자, 연산 기호만
EXPR_WORDS = {"x", "e", "pi", "sin", "cos", "tan", "log", "sqrt", "cbrt", "abs", "exp"}
X_AXIS = ("x축", "x-axis", "x")  # 넓이를 칠할 때 아래쪽 경계로 x축을 쓰는 경우


def fig_num(v, low=-1000.0):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or not low <= v <= 1000:
        raise ValueError("좌표가 숫자가 아님")
    return float(v)


def fig_text(v, n):
    return str(v or "").strip()[:n]


def curve_function(expr):
    """그래프 식을 파이썬 함수로 바꾼다 (설계도 검사용). 허용한 이름만 쓴 식이라 eval 해도 안전하다."""
    py = re.sub(r"(\d)\s*(?=[a-z(])", r"\1*", expr)          # 2x, 2(x+1) → 2*x, 2*(x+1)  (math.js 는 곱셈 생략 허용)
    py = re.sub(r"\)\s*(?=[a-z0-9(])", ")*", py).replace("^", "**")
    code = compile(py, "<식>", "eval")
    names = {"e": math.e, "pi": math.pi, "sin": math.sin, "cos": math.cos, "tan": math.tan, "log": math.log,
             "sqrt": math.sqrt, "abs": abs, "exp": math.exp, "cbrt": lambda v: math.copysign(abs(v) ** (1 / 3), v)}

    def f(x):
        y = eval(code, {"__builtins__": {}}, dict(names, x=x))
        if isinstance(y, complex) or not math.isfinite(y):
            raise ValueError("정의되지 않는 곳")
        return y
    return f


def clean_figure(fig):
    if not isinstance(fig, dict):
        return None
    try:
        kind = fig.get("type")
        if kind == "table":
            rows = [[fig_text(c, 60) for c in r[:8]] for r in fig["rows"][:8]]
            return {"type": "table", "rows": rows} if any(any(r) for r in rows) else None
        if kind not in ("graph", "geometry"):
            return None
        # hidden 점은 그리지 않고 보조선의 끝점으로만 쓴다 (점근선 위의 점, 수선의 발 등)
        points = [{"name": p["name"], "x": fig_num(p["x"]), "y": fig_num(p["y"]), "hidden": bool(p.get("hidden"))}
                  for p in fig.get("points", [])[:15] if POINT_NAME.match(str(p.get("name", "")))]
        names = {p["name"] for p in points}
        segments = [{"from": s["from"], "to": s["to"], "dashed": bool(s.get("dashed"))}
                    for s in fig.get("segments", [])[:20] if s.get("from") in names and s.get("to") in names]
        texts = [{"x": fig_num(t["x"]), "y": fig_num(t["y"]), "text": fig_text(t.get("text"), 20)}
                 for t in fig.get("texts", [])[:10] if fig_text(t.get("text"), 20)]
        out = {"type": kind, "points": points, "segments": segments, "texts": texts}
        if kind == "graph":
            x0, x1 = (fig_num(v) for v in fig["x"][:2])
            y0, y1 = (fig_num(v) for v in fig["y"][:2])
            if x0 >= x1 or y0 >= y1:
                return None
            functions = []
            for f in fig.get("functions", [])[:4]:
                expr = fig_text(f.get("expr"), 80).lower()
                # 허용한 함수 이름만 쓴 식인지 확인 (그리는 쪽에서 엉뚱한 명령이 실행되지 않게)
                if EXPR_CHARS.match(expr) and set(re.findall(r"[a-z]+", expr)) <= EXPR_WORDS:
                    curve_function(expr)  # 식이 문법에 맞는지 미리 확인 (틀리면 SyntaxError)
                    functions.append({"expr": expr, "label": fig_text(f.get("label"), 40)})
            # 점근선·보조선: x = 3 처럼 세로로, y = 1 처럼 가로로 그림 전체를 가로지르는 점선
            lines = []
            for ln in fig.get("lines", [])[:6]:
                if not isinstance(ln, dict) or not ("x" in ln or "y" in ln):
                    continue
                axis = "x" if "x" in ln else "y"
                lines.append({"axis": axis, "value": fig_num(ln[axis]), "dashed": ln.get("dashed", True) is not False})
            # 넓이 칠하기: 곡선 두 개 사이, 또는 곡선과 x축 사이
            regions = []
            for r in fig.get("regions", [])[:3]:
                top, bottom = r["between"][:2]
                a, b = (fig_num(v) for v in r["x"][:2])
                ok = lambda i: isinstance(i, int) and not isinstance(i, bool) and 0 <= i < len(functions)
                if ok(top) and (ok(bottom) or bottom in X_AXIS) and a < b:
                    regions.append({"top": top, "bottom": bottom if ok(bottom) else "x축", "x": [a, b]})
            out.update(x=[x0, x1], y=[y0, y1], functions=functions, lines=lines, regions=regions)
            return out if functions or points else None
        out["circles"] = [{"center": c["center"], "radius": fig_num(c["radius"], 0.001)}
                          for c in fig.get("circles", [])[:4] if c.get("center") in names]
        # 각 표시: 꼭짓점(at)에서 두 점(from, to) 쪽으로 호를 그린다. right 면 직각 표시
        out["angles"] = [{"at": g["at"], "from": g["from"], "to": g["to"], "right": bool(g.get("right")),
                          "text": fig_text(g.get("text"), 20)}
                         for g in fig.get("angles", [])[:6] if {g.get("at"), g.get("from"), g.get("to")} <= names]
        return out if segments or out["circles"] else None
    except (KeyError, IndexError, TypeError, ValueError, AttributeError, SyntaxError):
        return None


def figure_mismatch(fig):
    """그래프의 점이 어떤 곡선 '바로 옆'에 찍혀 있으면 (위에 있지도, 멀리 떨어져 있지도 않으면)
    곡선 위의 점을 의도했는데 AI가 좌표를 잘못 계산한 것으로 본다. 그런 점의 이름을 돌려준다."""
    if not fig or fig["type"] != "graph":
        return []
    span = fig["y"][1] - fig["y"][0]
    curves = [curve_function(f["expr"]) for f in fig["functions"]]
    wrong = []
    for p in fig["points"]:
        if p["hidden"]:
            continue  # 보조선 끝점은 곡선 근처에 있어도 괜찮다
        gaps = []
        for f in curves:
            try:
                gaps.append(abs(f(p["x"]) - p["y"]))
            except (ValueError, ZeroDivisionError, OverflowError, TypeError):
                pass
        on_curve = any(g <= max(0.01, span * 0.005) for g in gaps)
        near_curve = any(g <= span * 0.06 for g in gaps)
        if near_curve and not on_curve:
            wrong.append(p["name"])
    return wrong


def normalize_practice(data, strict=True):
    """연습 문제 응답 정리: 문제 목록 형식을 맞추고, 문제마다 그림 설계도를 검사한다.
    그래프의 점이 곡선과 살짝 어긋나 있으면 strict 일 때는 FigureMismatch 를 일으켜 새로 만들게 하고,
    마지막 시도(strict=False)에서는 그 그림만 뺀다."""
    problems = data.get("problems")
    problems = [p for p in problems if isinstance(p, dict)] if isinstance(problems, list) else []
    for p in problems:
        # "짝 문제에서는 ..." 처럼 자기 자신을 짝 문제라고 부르면 화면의 '짝 문제' 표시와 겹쳐서 '이 문제'로 바꾼다
        if isinstance(p.get("pair"), str):
            p["pair"] = re.sub(r"^\s*짝\s*문제(에서는|는)\s*", r"이 문제\1 ", p["pair"])
        p["figure"] = clean_figure(p.get("figure"))
        wrong = figure_mismatch(p["figure"])
        if wrong:
            if strict:
                raise FigureMismatch(f"점 {', '.join(wrong)} 이 곡선과 어긋남")
            print(f"[몽당] 그림의 점 {', '.join(wrong)} 이 곡선과 어긋나서 그림을 뺐어요.", flush=True)
            p["figure"] = None
    # 원래 문제에 그림이 있었다고 해 놓고 연습 문제에 그림을 빠뜨리면 한 번 새로 만든다
    if strict and data.get("original_figure") is True and problems and not all(p["figure"] for p in problems):
        raise FigureMismatch("원래 문제엔 그림이 있는데 연습 문제에 그림이 빠짐")
    # 짝 문제가 늘 같은 번호에 나오면 학생이 순서로 눈치챌 수 있어서, 보여 주는 순서를 섞는다
    random.shuffle(problems)
    return {"problems": problems}


# JSON 문자열 안의 LaTeX 백슬래시 고치기
# - 이미 두 번 쓴 백슬래시(\\)는 그대로 둔다
# - \log, \frac 처럼 뒤에 영문자가 2개 이상 오면 LaTeX 명령이므로 두 번 쓴 것으로 바꾼다
# - 그 밖에 JSON에서 허용되지 않는 \l, \( 같은 것도 두 번 쓴 것으로 바꾼다
_LATEX_BACKSLASH = re.compile(r'\\\\|\\(?=[A-Za-z]{2,})|\\(?![\\"/bfnrtu])')


def repair_backslashes(t):
    return _LATEX_BACKSLASH.sub(lambda m: m.group(0) if m.group(0) == "\\\\" else "\\\\", t)


def parse_json(text):
    t = (text or "").strip()
    if t.startswith("```"):
        t = t.strip("`").strip()
        if t.lower().startswith("json"):
            t = t[4:]
    try:
        data = json.loads(t)
    except json.JSONDecodeError:
        # AI가 LaTeX 백슬래시를 한 번만 쓰면 "Invalid \escape" 오류가 난다.
        # seed가 고정이라 다시 불러도 같은 응답이 오므로, 재시도 대신 여기서 고쳐서 읽는다.
        data = json.loads(repair_backslashes(t))
    if not isinstance(data, dict):
        raise ValueError("JSON 객체가 아님")
    return data


# =========================
# 요청 값 정리
# =========================
def parse_corrections(raw):
    """판독 정정 목록 (브라우저가 JSON 문자열로 보냄)"""
    try:
        items = json.loads(raw or "[]")
    except Exception:
        return []
    if not isinstance(items, list):
        return []
    return [{k: str(c.get(k, ""))[:500] for k in ("title", "read", "wrote")}
            for c in items[:20] if isinstance(c, dict) and str(c.get("wrote", "")).strip()]


def clean_list(raw, limit, max_len):
    """문자열 목록을 빈 값·중복 없이 정리"""
    out = []
    for x in raw if isinstance(raw, list) else []:
        s = str(x or "").strip().replace("\n", " ")[:max_len]
        if s and s not in out:
            out.append(s)
    return out[:limit]


def load_image(file_storage):
    img = Image.open(io.BytesIO(file_storage.read()))
    # 폰 사진은 EXIF 회전 정보로만 세워져 있는 경우가 많아서, 실제 픽셀을 바로 세워 준다
    img = ImageOps.exif_transpose(img)
    img = img.convert("RGB")
    if max(img.size) > 1600:
        img.thumbnail((1600, 1600))
    return img


def make_thumb(img, width=360):
    """기록에 함께 저장할 작은 사진 (JPEG 바이트)"""
    t = img.copy()
    t.thumbnail((width, width * 4))
    buf = io.BytesIO()
    t.save(buf, "JPEG", quality=70)
    return buf.getvalue()


# =========================
# 작업 (분석은 오래 걸려서 백그라운드 스레드로 돌리고, 브라우저는 /status 로 결과를 확인)
# =========================
JOBS = {}


def friendly_error(e):
    """오류를 학생이 보고 무엇을 하면 되는지 알 수 있는 문장으로 바꾼다. 원래 오류는 터미널에 그대로 남는다."""
    msg = f"{type(e).__name__} {e}"  # 인터넷 오류(ConnectError)는 메시지에 오류 이름이 없어서 함께 본다
    low = msg.lower()
    if "api_key_invalid" in low or "api key not valid" in low:
        return "Gemini API 키가 올바르지 않아요. 터미널에서 GEMINI_API_KEY를 다시 설정한 뒤 몽당을 다시 켜 주세요."
    if "429" in msg or "RESOURCE_EXHAUSTED" in msg:
        return "AI 사용량 한도에 걸렸어요. 1분쯤 뒤 다시 눌러 보고, 계속 안 되면 오늘 무료 사용량을 다 쓴 거라 내일 다시 시도해 주세요."
    if any(w in msg for w in ("503", "UNAVAILABLE", "high demand", "overloaded")):
        return "지금 AI 서버가 많이 붐벼요. 잠시 후 다시 눌러 주세요."
    if any(w in low for w in ("connecterror", "getaddrinfo", "name or service not known", "nodename nor servname",
                              "network is unreachable", "connection refused")):
        return "AI 서버에 연결할 수 없어요. 인터넷 연결을 확인하고 다시 눌러 주세요."
    if "timed out" in low or "timeout" in low or "deadline" in low:
        return "AI 응답이 너무 늦어요. 잠시 후 다시 시도해 주세요."
    return "AI 분석 중 오류가 났어요. 다시 시도해 주세요. (자세한 내용은 터미널에 있어요)"


class FigureMismatch(Exception):
    """연습 문제 그림의 점이 곡선 위에 있어야 할 것 같은데 살짝 어긋나 있음 = AI가 좌표 계산을 틀림"""


def run_json_job(job_id, contents, token_steps, post=None, varied=False):
    """모델을 불러 JSON을 받는다. 응답이 잘려 파싱이 안 되면 출력 한도를 늘려 한 번 더 시도.
    post 가 있으면 결과를 넘기기 전에 한 번 거친다 (분석 결과 정리·저장, 연습 문제 검사).
    연습 문제 그림이 문제와 안 맞으면(FigureMismatch) 새로 한 번 더 만들고, 마지막에도 안 맞으면 그 그림만 뺀다."""
    job = JOBS[job_id]
    deadline = time.time() + JOB_TIME_BUDGET
    try:
        for i, max_tokens in enumerate(token_steps):
            if time.time() >= deadline:
                break
            response = generate_with_retry(contents, max_tokens=max_tokens, deadline=deadline, varied=varied)
            text = response.text or ""
            try:
                data = parse_json(text)
            except (json.JSONDecodeError, ValueError):
                print(f"[몽당] JSON 파싱 실패 ({i+1}/{len(token_steps)}). 응답 끝부분:", text[-200:], flush=True)
                continue
            try:
                result = post(data) if post else data
            except FigureMismatch as e:
                print(f"[몽당] 연습 문제 그림이 문제와 안 맞음 ({e}). ({i+1}/{len(token_steps)})", flush=True)
                if i < len(token_steps) - 1:
                    continue  # 새로 만든다 (varied 라서 다른 문제가 나온다)
                result = post(data, strict=False)  # 마지막 시도: 안 맞는 그림만 빼고 보여 준다
            job.update(status="done", data=result)
            return
        job.update(status="error", error="AI 응답을 읽지 못했어요. 다시 한 번 시도해 주세요.")
    except Exception as e:
        print("[몽당] 작업 실패:", repr(e)[:300], flush=True)
        job.update(status="error", error=friendly_error(e))


def start_job(contents, token_steps, post=None, varied=False):
    """작업을 시작하고 작업 번호를 바로 돌려준다"""
    now = time.time()
    for k in [k for k, v in JOBS.items() if now - v["t"] > 1800]:  # 30분 지난 작업은 정리
        JOBS.pop(k, None)
    job_id = uuid.uuid4().hex
    JOBS[job_id] = {"status": "running", "t": now}
    threading.Thread(target=run_json_job, args=(job_id, contents, token_steps, post, varied), daemon=True).start()
    return jsonify({"job_id": job_id})


# =========================
# 기록 저장 (SQLite)
# =========================
# analyses : 분석 한 번 = 한 줄. AI 결과 전체(JSON)와 작은 사진을 같이 저장한다.
# mistakes : 그 분석에서 나온 자주 하는 실수. 실수 횟수와 실수 노트는 이 표에서 SQL로 바로 꺼낸다.
SCHEMA = """
CREATE TABLE IF NOT EXISTS analyses (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at      INTEGER NOT NULL,   -- 저장한 시각 (밀리초, 자바스크립트 Date와 같은 단위)
    verdict         TEXT,
    one_line        TEXT,
    problem         TEXT,
    primary_concept TEXT,
    data_json       TEXT NOT NULL,
    problem_thumb   BLOB,
    solution_thumb  BLOB
);
CREATE TABLE IF NOT EXISTS mistakes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    analysis_id INTEGER NOT NULL REFERENCES analyses(id),
    created_at  INTEGER NOT NULL,
    mistake     TEXT NOT NULL,
    step        TEXT,
    wrote       TEXT,
    why_wrong   TEXT,
    correct     TEXT
);
"""


def init_db():
    """기록 파일과 표를 만든다. 앱 폴더에 쓸 수 없으면 (맥 바탕화면 권한 등) 홈 폴더에 만든다."""
    global DB_PATH
    for path in (DB_PATH, os.path.join(os.path.expanduser("~"), "mongdang.db")):
        try:
            with closing(sqlite3.connect(path)) as con:
                con.executescript(SCHEMA)
            DB_PATH = path
            print("[몽당] 기록 파일:", path, flush=True)
            return
        except sqlite3.Error as e:
            print(f"[몽당] {path} 에 기록 파일을 만들 수 없어요 ({e})", flush=True)
    raise SystemExit("기록 파일(mongdang.db)을 만들 수 없습니다.")


@contextmanager
def db():
    """요청마다 새로 연결한다. 분석 결과는 다른 스레드에서 저장되기 때문에 연결을 함께 쓰지 않는다."""
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row  # 결과를 row["열 이름"] 으로 읽을 수 있게
    try:
        with con:  # 블록이 정상으로 끝나면 저장(commit), 중간에 오류가 나면 되돌림(rollback)
            yield con
    finally:
        con.close()


def save_record(con, data, thumbs):
    """분석 결과 하나를 저장하고 기록 번호를 돌려준다"""
    now = int(time.time() * 1000)
    cur = con.execute(
        "INSERT INTO analyses (created_at, verdict, one_line, problem, primary_concept, data_json, problem_thumb, solution_thumb)"
        " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (now, str(data.get("verdict", "")), str(data.get("one_line", "")), str(data.get("problem", "")),
         data["primary_concept"], json.dumps(data, ensure_ascii=False), thumbs["problem"], thumbs["solution"]))
    saved = set()
    for e in data.get("errors") or []:
        mistake = str(e.get("mistake") or "").strip()
        if mistake and mistake not in saved:  # 한 분석 안에서 같은 실수가 두 번 나와도 한 번만 센다
            saved.add(mistake)
            con.execute(
                "INSERT INTO mistakes (analysis_id, created_at, mistake, step, wrote, why_wrong, correct)"
                " VALUES (?, ?, ?, ?, ?, ?, ?)",
                (cur.lastrowid, now, mistake, *(str(e.get(k) or "") for k in ("step", "wrote", "why_wrong", "correct"))))
    return cur.lastrowid


def delete_record(con, analysis_id):
    con.execute("DELETE FROM mistakes WHERE analysis_id = ?", (analysis_id,))
    con.execute("DELETE FROM analyses WHERE id = ?", (analysis_id,))


def mistake_counts(con, data):
    """이 분석에 나온 실수가 지금까지 전체 기록에서 몇 번 나왔는지 {실수: 횟수}"""
    counts = {}
    for e in data.get("errors") or []:
        mistake = str(e.get("mistake") or "").strip()
        if mistake:
            counts[mistake] = con.execute("SELECT COUNT(*) FROM mistakes WHERE mistake = ?", (mistake,)).fetchone()[0]
    return counts


def known_mistakes():
    """AI에게 알려 줄 이전 실수 목록 (많이 나온 순, 최대 30개)"""
    with db() as con:
        rows = con.execute("SELECT mistake FROM mistakes GROUP BY mistake"
                           " ORDER BY COUNT(*) DESC, MAX(created_at) DESC LIMIT 30").fetchall()
    return [r["mistake"] for r in rows]


def save_after_analysis(data, thumbs, replace_id):
    """분석이 끝나면 바로 저장한다. 판독을 고쳐 다시 분석한 것이면 원래 기록은 지운다 (같은 풀이가 두 번 세어지지 않게).
    저장에 실패해도 분석 결과는 그대로 보여 준다."""
    data = normalize_analysis(data)
    try:
        with db() as con:
            if replace_id:
                delete_record(con, replace_id)
            history_id = save_record(con, data, thumbs)
            counts = mistake_counts(con, data)
        data.update(history_id=history_id, mistake_counts=counts)
    except Exception as e:
        print("[몽당] 기록 저장 실패:", repr(e)[:200], flush=True)
    return data


# =========================
# 주소 (라우트)
# =========================
@app.route("/")
def index():
    return render_template("index.html")  # templates/index.html


@app.route("/analyze", methods=["POST"])
def analyze():
    single = request.form.get("single") == "1"
    photos = [request.files.get("problem")] if single else [request.files.get("problem"), request.files.get("solution")]
    if not all(photos):
        return jsonify({"error": "문제 사진과 풀이 사진을 모두 올려주세요."}), 400
    try:
        imgs = [load_image(f) for f in photos]
    except Exception:
        if any((f.filename or "").lower().endswith((".heic", ".heif")) for f in photos):
            return jsonify({"error": "아이폰 HEIC 사진은 아직 읽을 수 없어요. JPG로 바꾸거나 화면을 캡처해서 올려 주세요."}), 400
        return jsonify({"error": "이미지를 읽을 수 없어요. 다른 사진으로 시도해 주세요."}), 400
    corrections = parse_corrections(request.form.get("corrections"))
    replace_id = request.form.get("replace", type=int)  # 판독을 고쳐 다시 분석할 때, 바꿀 원래 기록 번호
    thumbs = {"problem": make_thumb(imgs[0]), "solution": make_thumb(imgs[1]) if len(imgs) > 1 else None}
    # 전에 찾은 자주 하는 실수를 같이 보내서, 같은 실수면 같은 문장으로 쓰게 한다 (반복 횟수를 세기 위해)
    prompt = build_prompt(single, corrections, known_mistakes())
    return start_job([prompt] + imgs, (12000, 20000), post=lambda data: save_after_analysis(data, thumbs, replace_id))


@app.route("/practice", methods=["POST"])
def practice():
    b = request.get_json(silent=True) or {}
    problem = str(b.get("problem") or "").strip()[:3000]
    if not problem:
        return jsonify({"error": "원래 문제 정보가 없어요."}), 400
    concepts = clean_list(b.get("concepts"), 3, 50)
    mistakes = clean_list(b.get("mistakes"), 3, 200)
    avoid = clean_list(b.get("avoid"), 4, 400)  # 이 화면에서 이미 낸 문제 (다시 누르면 다른 문제가 나오게)
    level = str(b.get("level") or "")
    # 원래 문제 사진(저장해 둔 작은 사진)도 함께 보내서, 그림·그래프가 있던 문제인지 AI가 직접 보게 한다
    # 학교급도 저장된 분석 기록에 있으면 그걸 쓴다 (실수 노트에서 만들 때도 같은 학교급으로)
    photo = None
    history_id = b.get("history_id")
    if isinstance(history_id, int):
        with db() as con:
            row = con.execute("SELECT problem_thumb, data_json FROM analyses WHERE id = ?", (history_id,)).fetchone()
        if row:
            photo = Image.open(io.BytesIO(row[0])) if row[0] else None
            try:
                level = json.loads(row[1]).get("level") or level
            except (TypeError, ValueError, AttributeError):
                pass
    contents = [build_practice_prompt(problem, concepts, mistakes, avoid, level)]
    if photo:
        contents.append(photo)
    return start_job(contents, (8000, 14000), post=normalize_practice, varied=True)


@app.route("/status/<job_id>")
def status(job_id):
    job = JOBS.get(job_id)
    if not job:
        return jsonify({"status": "error", "error": "작업을 찾을 수 없어요. 다시 시도해 주세요."})
    return jsonify({k: v for k, v in job.items() if k != "t"})


@app.route("/history")
def history():
    """내 흔적 화면에 필요한 것을 한 번에: 통계, 자주 하는 실수, 핵심 개념 순위, 지난 분석 목록"""
    with db() as con:
        total, right, wrong = con.execute(
            "SELECT COUNT(*), COALESCE(SUM(verdict = '정답'), 0), COALESCE(SUM(verdict = '오답'), 0) FROM analyses").fetchone()
        mistakes = con.execute(
            "SELECT mistake, COUNT(*) AS count, MAX(created_at) AS last FROM mistakes"
            " GROUP BY mistake ORDER BY count DESC, last DESC LIMIT 10").fetchall()
        # 핵심 개념만 센다 (함께 고른 관련 개념은 매번 조금씩 달라질 수 있어서 통계에서 뺌)
        concepts = con.execute(
            "SELECT primary_concept AS name, COUNT(*) AS count FROM analyses WHERE primary_concept != ''"
            " GROUP BY primary_concept ORDER BY count DESC LIMIT 6").fetchall()
        items = con.execute(
            "SELECT id, created_at, verdict, one_line FROM analyses ORDER BY created_at DESC LIMIT 100").fetchall()
    return jsonify({"total": total, "right": right, "wrong": wrong,
                    "mistakes": [dict(r) for r in mistakes],
                    "concepts": [dict(r) for r in concepts],
                    "items": [dict(r) for r in items]})


@app.route("/history/<int:hid>")
def history_one(hid):
    with db() as con:
        row = con.execute("SELECT data_json, solution_thumb IS NOT NULL AS has_solution FROM analyses WHERE id = ?",
                          (hid,)).fetchone()
        if not row:
            return jsonify({"error": "기록을 찾을 수 없어요."}), 404
        data = normalize_analysis(json.loads(row["data_json"]))
        data.update(history_id=hid, mistake_counts=mistake_counts(con, data))
    thumbs = {"problem": f"/thumb/{hid}/problem", "solution": f"/thumb/{hid}/solution" if row["has_solution"] else None}
    return jsonify({"data": data, "thumbs": thumbs})


@app.route("/history/<int:hid>", methods=["DELETE"])
def history_delete(hid):
    with db() as con:
        delete_record(con, hid)
    return jsonify({"ok": True})


@app.route("/thumb/<int:hid>/<kind>")
def thumb(hid, kind):
    if kind not in ("problem", "solution"):
        return "", 404
    with db() as con:
        row = con.execute(f"SELECT {kind}_thumb FROM analyses WHERE id = ?", (hid,)).fetchone()
    if not row or not row[0]:
        return "", 404
    return Response(row[0], mimetype="image/jpeg")


@app.route("/mistake-note")
def mistake_note():
    """자주 하는 실수 하나가 나온 문제를 최근 순으로 모두 모은다"""
    text = request.args.get("text", "").strip()
    with db() as con:
        rows = con.execute(
            "SELECT m.analysis_id AS id, m.created_at, m.step, m.wrote, m.why_wrong, m.correct, a.verdict, a.problem"
            " FROM mistakes m JOIN analyses a ON a.id = m.analysis_id"
            " WHERE m.mistake = ? ORDER BY m.created_at DESC", (text,)).fetchall()
    if not rows:
        return jsonify({"error": "이 실수가 나온 기록이 없어요."}), 404
    return jsonify({"text": text, "items": [dict(r) for r in rows]})


if __name__ == "__main__":
    init_db()
    # host="0.0.0.0" 으로 바꾸면 같은 와이파이의 폰에서도 접속 가능
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
