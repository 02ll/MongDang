"""
몽당 연습 문제 품질 확인 스크립트 (13주차)
실제 Gemini로 풀이를 한 번 분석한 뒤, 그 결과로 연습 문제를 여러 번 만들어 보고
그림(설계도), 함정, 짝 문제가 제대로 나오는지 정리한다. 만든 문제는 전부 파일에 저장한다.

사용법 (GEMINI_API_KEY 가 설정된 터미널에서, 이 폴더 안에서):
    python check_practice.py                       # 22_9_21.png(문제), 22_9_21_X.jpeg(풀이) 로 3번
    python check_practice.py 문제사진 풀이사진 --runs 5

- 앱(mongdang.py)의 함수를 그대로 불러 쓴다. 서버를 켤 필요는 없다.
- 결과 파일(practice_check.json)을 보면 문제, 정답, 그림 설계도를 하나하나 확인할 수 있다.
"""
import argparse
import importlib.util
import json
import os
import sys
import time


def load_app(path):
    spec = importlib.util.spec_from_file_location("mongdang_app", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def describe(fig):
    if not fig:
        return "그림 없음"
    if fig["type"] == "table":
        return f"표 {len(fig['rows'])}줄"
    parts = [f"점 {len([p for p in fig['points'] if not p['hidden']])}"]
    if fig["type"] == "graph":
        parts.insert(0, f"곡선 {len(fig['functions'])}")
        parts += [f"보조선 {len(fig['lines'])}"] if fig["lines"] else []
        parts += [f"넓이 {len(fig['regions'])}"] if fig["regions"] else []
        return "그래프 (" + ", ".join(parts) + ")"
    parts += [f"원 {len(fig['circles'])}"] if fig["circles"] else []
    parts += [f"각 {len(fig['angles'])}"] if fig["angles"] else []
    return "도형 (" + ", ".join(parts) + ")"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("problem", nargs="?", default="22_9_21.png")
    ap.add_argument("solution", nargs="?", default="22_9_21_X.jpeg")
    ap.add_argument("--runs", type=int, default=3, help="연습 문제를 만들어 볼 횟수 (기본 3)")
    ap.add_argument("--out", default="practice_check.json")
    args = ap.parse_args()
    here = os.path.dirname(os.path.abspath(__file__))
    fix = lambda p: p if os.path.isabs(p) else os.path.join(here, p)
    for p in (args.problem, args.solution):
        if not os.path.exists(fix(p)):
            sys.exit(f"사진을 찾을 수 없어요: {p}  (이 폴더에 22_9_21.png, 22_9_21_X.jpeg 를 두거나 경로를 적어 주세요)")
    m = load_app(os.path.join(here, "mongdang.py"))

    # 1) 풀이 분석 (앱과 같은 방식)
    print("[분석] 풀이를 분석하는 중...", flush=True)
    with open(fix(args.problem), "rb") as f1, open(fix(args.solution), "rb") as f2:
        imgs = [m.load_image(f1), m.load_image(f2)]
    resp = m.generate_with_retry([m.build_prompt(False, [], [])] + imgs, deadline=time.time() + 200)
    data = m.normalize_analysis(m.parse_json(resp.text))
    mistakes = [e.get("mistake", "") for e in data["errors"] if e.get("mistake")]
    print(f"[분석] 학교급: {data['level'] or '(모름)'} / 판정: {data['verdict']} / 자주 하는 실수: {mistakes or '(없음)'}")

    # 2) 연습 문제 여러 번 만들기 (앱의 /practice 와 같은 방식: 원래 문제 사진도 함께, 그림이 어긋나면 한 번 새로)
    thumb = imgs[0].copy()
    thumb.thumbnail((360, 1440))  # 앱은 저장해 둔 작은 사진을 보낸다
    runs, seen = [], []
    for k in range(1, args.runs + 1):
        print(f"\n[연습 {k}/{args.runs}] 만드는 중...", flush=True)
        # 앱에서 버튼을 다시 누른 것처럼, 앞에서 낸 문제는 피하게 한다
        contents = [m.build_practice_prompt(data["problem"], data["concepts"], mistakes, seen[:4], data["level"]), thumb]
        t0, remade, result = time.time(), 0, None
        steps = (8000, 14000)
        for i, max_tokens in enumerate(steps):
            text = m.generate_with_retry(contents, max_tokens=max_tokens, deadline=time.time() + 200, varied=True).text
            try:
                raw = m.parse_json(text)
            except (json.JSONDecodeError, ValueError):
                print("  응답을 읽지 못해 다시 시도")
                continue
            try:
                result = m.normalize_practice(json.loads(json.dumps(raw)))
            except m.FigureMismatch as e:
                remade += 1
                print(f"  그림이 문제와 안 맞아서 새로 만듦 ({e})")
                if i < len(steps) - 1:
                    continue
                result = m.normalize_practice(raw, strict=False)
            break
        sec = round(time.time() - t0, 1)
        if not result:
            print(f"  실패 ({sec}초)")
            runs.append({"run": k, "ok": False, "seconds": sec})
            continue
        print(f"  {sec}초, 새로 만든 횟수 {remade}")
        for p in result["problems"]:
            kind = "짝 문제" if p.get("pair") else ("실수 문제" if p.get("trap") else "일반")
            print(f"  - [{kind}] {describe(p['figure'])} / 정답 {str(p.get('answer'))[:30]}")
        runs.append({"run": k, "ok": True, "seconds": sec, "remade": remade, "problems": result["problems"]})
        seen = [str(p.get("question", "")) for p in result["problems"]] + seen

    ok = [r for r in runs if r["ok"]]
    probs = [p for r in ok for p in r["problems"]]
    print("\n================ 요약 ================")
    print(f"성공 {len(ok)}/{len(runs)}번, 평균 {sum(r['seconds'] for r in ok) / max(len(ok), 1):.1f}초")
    print(f"그림 있는 문제 {sum(1 for p in probs if p.get('figure'))}/{len(probs)}")
    print(f"짝 문제가 들어 있는 세트 {sum(1 for r in ok if any(p.get('pair') for p in r['problems']))}/{len(ok)}")
    print(f"그림이 어긋나서 새로 만든 횟수 {sum(r['remade'] for r in ok)}")
    payload = json.dumps({"analysis": {"level": data["level"], "verdict": data["verdict"], "problem": data["problem"], "mistakes": mistakes},
                          "runs": runs}, ensure_ascii=False, indent=2)
    for path in (fix(args.out), os.path.join(os.path.expanduser("~"), os.path.basename(args.out))):
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(payload)
            print(f"\n만든 문제 전체를 {path} 에 저장했어요. 이 파일을 보내 주면 정답과 그림을 하나하나 확인할 수 있어요.")
            break
        except OSError:
            continue


if __name__ == "__main__":
    main()
