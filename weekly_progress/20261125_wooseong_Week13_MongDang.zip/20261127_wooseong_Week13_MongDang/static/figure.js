/* 연습 문제 그림 (그래프·도형·표)
   AI는 설계도(함수식, 점 좌표, 표 내용)만 주고, 그림은 여기서 직접 계산해서 그린다.
   그래서 곡선이나 교점이 AI 때문에 틀리게 그려질 일이 없다.
   설계도가 이상해서 그리다 오류가 나면 그림만 빼고 문제는 그대로 보여 준다. */

let figureCount = 0;  // 한 화면에 그림이 여러 개일 때 SVG 안의 id가 겹치지 않게

// 문제 카드 안에 넣을 자리. 표는 바로 HTML로 만들고, 그래프·도형은 자리만 만든 뒤 drawFigure 가 채운다
function figureHTML(fig) {
  if (!fig) return '';
  if (fig.type === 'table') {
    return `<table class="ftable">${fig.rows.map(r =>
      `<tr>${r.map(c => `<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</table>`;
  }
  return '<div class="fig"></div>';
}

// 그릴 범위: 그래프는 설계도의 x, y 범위 그대로, 도형은 모든 점과 원이 들어가게 여백을 둔다
function figureBox(fig) {
  if (fig.type === 'graph') return { x0: fig.x[0], x1: fig.x[1], y0: fig.y[0], y1: fig.y[1] };
  const xs = [], ys = [];
  const pts = Object.fromEntries(fig.points.map(p => [p.name, p]));
  fig.points.forEach(p => { xs.push(p.x); ys.push(p.y); });
  fig.circles.forEach(c => {
    const o = pts[c.center];
    xs.push(o.x - c.radius, o.x + c.radius); ys.push(o.y - c.radius, o.y + c.radius);
  });
  const pad = Math.max(Math.max(...xs) - Math.min(...xs), Math.max(...ys) - Math.min(...ys), 1) * 0.15;
  return { x0: Math.min(...xs) - pad, x1: Math.max(...xs) + pad, y0: Math.min(...ys) - pad, y1: Math.max(...ys) + pad };
}

// 식 f 에 x 를 넣은 값. 정의되지 않으면(로그의 음수 등) null
function valueAt(f, x) {
  try { const y = f.evaluate({ x }); return typeof y === 'number' && isFinite(y) ? y : null; } catch { return null; }
}

// 함수 그래프: x를 600칸으로 나눠 실제 값을 계산하고 점을 이어 그린다
function curvePath(expr, box, X, Y) {
  const f = math.compile(expr);  // math.js 가 식을 해석해서 계산할 수 있는 함수로 만든다
  const span = box.y1 - box.y0, mid = (box.y0 + box.y1) / 2;
  let d = '', prev = null;
  const spots = [], ink = [];  // 이름표를 붙일 수 있는 자리, 곡선이 지나가는 화면 위치
  for (let i = 0; i <= 600; i++) {
    const x = box.x0 + (box.x1 - box.x0) * i / 600;
    let y;
    try { y = f.evaluate({ x }); } catch { y = NaN; }
    // 정의되지 않는 곳(로그의 음수 등)이나 화면에서 너무 먼 값은 건너뛴다
    if (typeof y !== 'number' || !isFinite(y) || Math.abs(y - mid) > span * 3) { prev = null; continue; }
    const jump = prev !== null && Math.abs(y - prev) > span;  // 점근선 양쪽을 선으로 잇지 않게
    d += `${prev === null || jump ? 'M' : 'L'}${X(x).toFixed(1)},${Y(y).toFixed(1)}`;
    prev = y;
    if (y >= box.y0 && y <= box.y1) ink.push({ x: X(x), y: Y(y) });
    if (y > box.y0 + span * 0.08 && y < box.y1 - span * 0.08 && x < box.x1 - (box.x1 - box.x0) * 0.04) spots.push({ x, y });
  }
  return { d, spots, ink };
}

function drawFigure(el, fig) {
  try {
    const n = ++figureCount;
    const box = figureBox(fig);
    const avail = el.parentElement.getBoundingClientRect().width - 48;
    let W = avail > 120 ? Math.min(360, avail) : 360;
    let H = W * (box.y1 - box.y0) / (box.x1 - box.x0);           // 가로세로를 같은 비율로
    if (fig.type === 'graph') H = Math.min(Math.max(H, 200), 380); // 그래프는 너무 납작하거나 길지 않게만
    else if (H > 360) { W = W * 360 / H; H = 360; }                // 도형은 비율을 꼭 지킨다 (원이 찌그러지지 않게)
    const X = x => (x - box.x0) / (box.x1 - box.x0) * W;
    const Y = y => H - (y - box.y0) / (box.y1 - box.y0) * H;
    const f1 = v => v.toFixed(1);

    const shapes = [], labels = [];
    const label = (x, y, text, cls = '') =>
      labels.push(`<span class="lb ${cls}" style="left:${f1(x)}px;top:${f1(y)}px">${esc(text)}</span>`);
    const line = (x1, y1, x2, y2, cls) =>
      shapes.push(`<line class="${cls}" x1="${f1(x1)}" y1="${f1(y1)}" x2="${f1(x2)}" y2="${f1(y2)}"/>`);
    const pts = Object.fromEntries(fig.points.map(p => [p.name, p]));

    // 이름표가 선이나 다른 이름표와 겹치지 않게: 선이 지나가는 화면 위치(ink)와 붙인 이름표 영역(placed)을 모아 두고 피한다
    const ink = [], placed = [];
    const inkLine = (x1, y1, x2, y2, k) => {
      const steps = Math.ceil(Math.hypot(x2 - x1, y2 - y1) / 6);
      for (let i = 0; i <= steps; i++) ink.push({ x: x1 + (x2 - x1) * i / steps, y: y1 + (y2 - y1) * i / steps, k });
    };
    const hits = (r, skip) =>
      ink.filter(p => p.k !== skip && p.x > r[0] && p.x < r[2] && p.y > r[1] && p.y < r[3]).length +
      placed.filter(q => q[0] < r[2] && r[0] < q[2] && q[1] < r[3] && r[1] < q[3]).length * 100;
    const mark = (x, y, w = 16, h = 18) => placed.push([x - w / 2, y - h / 2, x + w / 2, y + h / 2]);

    fig.segments.forEach(s => {
      const a = pts[s.from], b = pts[s.to];
      line(X(a.x), Y(a.y), X(b.x), Y(b.y), s.dashed ? 'ln dash' : 'ln');
      inkLine(X(a.x), Y(a.y), X(b.x), Y(b.y), 'seg');
    });

    if (fig.type === 'graph') {
      // 좌표축: 수능 그림처럼 화살표와 x, y, O (범위가 0에서 시작해도 가장자리에 축을 그린다)
      const hasX = box.y0 <= 0 && box.y1 > 0, hasY = box.x0 <= 0 && box.x1 > 0;
      if (hasX) {
        shapes.push(`<line class="axis" x1="0" y1="${f1(Y(0))}" x2="${f1(W)}" y2="${f1(Y(0))}" marker-end="url(#ar${n})"/>`);
        inkLine(0, Y(0), W, Y(0), 'axis'); label(W - 4, Y(0) + 13, 'x', 'it'); mark(W - 4, Y(0) + 13);
      }
      if (hasY) {
        shapes.push(`<line class="axis" x1="${f1(X(0))}" y1="${f1(H)}" x2="${f1(X(0))}" y2="0" marker-end="url(#ar${n})"/>`);
        inkLine(X(0), H, X(0), 0, 'axis'); label(X(0) + 12, 6, 'y', 'it'); mark(X(0) + 12, 6);
      }
      if (hasX && hasY) { label(X(0) - 10, Y(0) + 12, 'O', 'it'); mark(X(0) - 10, Y(0) + 12); }
      // 점근선·보조선: x = 3 은 세로로, y = 1 은 가로로 그림 전체를 가로지른다
      (fig.lines || []).forEach(l => {
        const inside = l.axis === 'x' ? l.value > box.x0 && l.value < box.x1 : l.value > box.y0 && l.value < box.y1;
        if (!inside) return;
        const [x1, y1, x2, y2] = l.axis === 'x' ? [X(l.value), 0, X(l.value), H] : [0, Y(l.value), W, Y(l.value)];
        line(x1, y1, x2, y2, l.dashed ? 'ln dash' : 'ln');
        inkLine(x1, y1, x2, y2, 'line');
      });
      // 넓이: 위쪽 곡선을 따라갔다가 아래쪽 곡선(또는 x축)을 거꾸로 따라와 닫힌 모양을 만들어 칠한다
      (fig.regions || []).forEach(r => {
        const top = math.compile(fig.functions[r.top].expr);
        const bottom = r.bottom === 'x축' ? null : math.compile(fig.functions[r.bottom].expr);
        const a = Math.max(r.x[0], box.x0), b = Math.min(r.x[1], box.x1);
        const up = [], down = [];
        for (let i = 0; i <= 200; i++) {
          const x = a + (b - a) * i / 200;
          const yt = valueAt(top, x), yb = bottom ? valueAt(bottom, x) : 0;
          if (yt === null || yb === null) continue;
          up.push(`${f1(X(x))},${f1(Y(yt))}`);
          down.unshift(`${f1(X(x))},${f1(Y(yb))}`);
        }
        if (up.length > 1) shapes.unshift(`<polygon class="area" points="${up.concat(down).join(' ')}" clip-path="url(#cp${n})"/>`);
      });
      const curves = fig.functions.map((f, k) => ({ f, k, ...curvePath(f.expr, box, X, Y) }));
      curves.forEach(c => {
        if (c.d) shapes.push(`<path class="curve" d="${c.d}" clip-path="url(#cp${n})"/>`);
        c.ink.forEach(p => ink.push({ ...p, k: c.k }));
      });
      curves.forEach(c => {
        if (!c.f.label || !c.spots.length) return;
        // 이름표 너비 어림: 수식 기호를 뺀 글자 수로 계산 (긴 식일수록 넓게 비켜 간다)
        const w = Math.min(160, 14 + 11 * c.f.label.replace(/\\[a-z]+|[$^_{}\s]/g, m => m.length > 1 ? 'xx' : '').length);
        // 곡선의 오른쪽 끝에서부터 왼쪽으로 옮겨 가며, 곡선 점의 왼쪽 위·왼쪽 아래·오른쪽 위·오른쪽 아래 중
        // 다른 선과 이름표, 자기 곡선과 가장 덜 겹치는 자리를 고른다 (오른쪽 끝 근처의 왼쪽 자리를 먼저 본다)
        let best = null;
        for (let i = c.spots.length - 1; i >= 0; i -= 6) {
          const px = X(c.spots[i].x) - 4, py = Y(c.spots[i].y);
          const qx = px + 8;  // 오른쪽 자리는 점에서 조금 띄운다
          for (const [x, y, rect, cls] of [
            [px, py - 4, [px - w, py - 26, px, py - 4], 'end'], [px, py + 4, [px - w, py + 4, px, py + 26], 'endlow'],
            [qx, py - 4, [qx, py - 26, qx + w, py - 4], 'start'], [qx, py + 4, [qx, py + 4, qx + w, py + 26], 'startlow']]) {
            const outside = rect[0] < 0 || rect[1] < 0 || rect[2] > W || rect[3] > H;  // 그림 밖으로 나가는 자리는 되도록 피한다
            const score = hits(rect, null) + (outside ? 8 : 0);
            if (!best || score < best.score) best = { x, y, rect, cls, score };
          }
          if (best.score === 0) break;
        }
        label(best.x, best.y, c.f.label, best.cls);
        placed.push(best.rect);
      });
    } else {
      fig.circles.forEach(c => {
        const o = pts[c.center];
        shapes.push(`<circle class="ln" cx="${f1(X(o.x))}" cy="${f1(Y(o.y))}" r="${f1(c.radius * W / (box.x1 - box.x0))}"/>`);
      });
      // 각 표시: 꼭짓점에서 두 점 쪽 방향 사이에 작은 호, 직각이면 작은 꺾쇠
      (fig.angles || []).forEach(g => {
        const v = pts[g.at], a = pts[g.from], c = pts[g.to];
        const ux = X(a.x) - X(v.x), uy = Y(a.y) - Y(v.y), wx = X(c.x) - X(v.x), wy = Y(c.y) - Y(v.y);
        const lu = Math.hypot(ux, uy), lw = Math.hypot(wx, wy);
        if (!lu || !lw) return;
        const [u1, u2, w1, w2] = [ux / lu, uy / lu, wx / lw, wy / lw];
        const vx = X(v.x), vy = Y(v.y);
        if (g.right) {
          const s = 10;
          shapes.push(`<path class="ln thin" d="M${f1(vx + u1 * s)},${f1(vy + u2 * s)} L${f1(vx + (u1 + w1) * s)},${f1(vy + (u2 + w2) * s)} L${f1(vx + w1 * s)},${f1(vy + w2 * s)}"/>`);
        } else {
          const r = 18, sweep = u1 * w2 - u2 * w1 > 0 ? 1 : 0;  // 두 방향 사이의 작은 쪽으로 돈다
          shapes.push(`<path class="ln thin" d="M${f1(vx + u1 * r)},${f1(vy + u2 * r)} A${r},${r} 0 0,${sweep} ${f1(vx + w1 * r)},${f1(vy + w2 * r)}"/>`);
        }
        if (g.text) {  // 글자는 두 방향의 가운데 쪽에
          const bx = u1 + w1, by = u2 + w2, bl = Math.hypot(bx, by) || 1;
          label(vx + bx / bl * 32, vy + by / bl * 32, g.text);
        }
      });
    }
    // 점과 이름: 도형은 점들의 가운데에서 바깥쪽으로, 그래프는 주변 8방향 중 선과 가장 덜 겹치는 쪽에 붙인다
    const inView = p => p.x >= box.x0 && p.x <= box.x1 && p.y >= box.y0 && p.y <= box.y1;
    const shown = fig.points.filter(p => !p.hidden && inView(p));  // 숨긴 점(보조선 끝점)은 그리지 않는다
    const cx = shown.reduce((s, p) => s + p.x, 0) / (shown.length || 1);
    const cy = shown.reduce((s, p) => s + p.y, 0) / (shown.length || 1);
    shown.forEach(p => {
      shapes.push(`<circle class="pt" cx="${f1(X(p.x))}" cy="${f1(Y(p.y))}" r="3"/>`);
      let dx = 10, dy = -10;
      if (fig.type === 'graph') {
        const dirs = [[10, -10], [-10, -10], [10, 10], [-10, 10], [0, -13], [13, 0], [0, 13], [-13, 0]];
        let best = Infinity;
        dirs.forEach(([ex, ey]) => {
          const x = X(p.x) + ex, y = Y(p.y) + ey, score = hits([x - 7, y - 8, x + 7, y + 8], null);
          if (score < best) { best = score; dx = ex; dy = ey; }
        });
      } else {
        const vx = X(p.x) - X(cx), vy = Y(p.y) - Y(cy), len = Math.hypot(vx, vy);
        if (len > 8) { dx = vx / len * 14; dy = vy / len * 14; } else { dx = 11; dy = 12; }  // 가운데 점(원의 중심 등)은 오른쪽 아래
      }
      label(X(p.x) + dx, Y(p.y) + dy, p.name);
      mark(X(p.x) + dx, Y(p.y) + dy);
    });
    fig.texts.forEach(t => label(X(t.x), Y(t.y), t.text));

    el.style.width = W + 'px';
    el.style.height = H + 'px';
    el.innerHTML = `<svg width="${f1(W)}" height="${f1(H)}" viewBox="0 0 ${f1(W)} ${f1(H)}">
      <defs>
        <marker id="ar${n}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0,0 L10,5 L0,10 z"/></marker>
        <clipPath id="cp${n}"><rect width="${f1(W)}" height="${f1(H)}"/></clipPath>
      </defs>${shapes.join('')}</svg>${labels.join('')}`;
  } catch (e) {
    console.warn('그림을 그리지 못해 문제만 보여 줍니다:', e);
    el.remove();
  }
}
